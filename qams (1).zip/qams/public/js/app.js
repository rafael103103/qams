// App shell: auth guard, sidebar, router, notification bell, theme toggle.
const Pages = {};   // filled by js/pages/*.js : Pages.name = async (view, params) => {...}
let charts = [];    // Chart.js instances, destroyed on navigation to avoid leaks

const NAV = [
  { section: 'Main' },
  { id: 'dashboard', icon: 'speedometer2', label: 'Dashboard' },
  { id: 'requests', icon: 'file-earmark-text', label: 'Approval Requests' },
  { id: 'approvals', icon: 'check2-square', label: 'My Approvals', roles: ['engineer', 'supervisor', 'qa_manager'], badge: true },
  { section: 'Tools' },
  { id: 'ai', icon: 'stars', label: 'AI Assistant' },
  { id: 'documents', icon: 'folder2-open', label: 'Document Repository' },
  { id: 'reports', icon: 'bar-chart-line', label: 'Reports', roles: ['engineer', 'supervisor', 'qa_manager'] },
  { section: 'Master Data' },
  { id: 'customers', icon: 'buildings', label: 'Customers' },
  { id: 'parts', icon: 'gear-wide-connected', label: 'Parts' },
  { section: 'Administration', roles: ['qa_manager'] },
  { id: 'audit', icon: 'journal-check', label: 'Audit Trail', roles: ['qa_manager'] },
  { id: 'users', icon: 'people', label: 'Users', roles: ['admin'] },
];

function allowed(item) { return !item.roles || can(...item.roles); }

function buildNav() {
  $('#nav').innerHTML = NAV.filter(allowed).map((n) => n.section
    ? `<div class="nav-section">${n.section}</div>`
    : `<a class="nav-link" href="#/${n.id}" data-id="${n.id}"><i class="bi bi-${n.icon}"></i><span>${n.label}</span>${n.badge ? '<span class="badge bg-danger ms-auto d-none" id="apprBadge"></span>' : ''}</a>`).join('');
}

function setActive(id) {
  $$('#nav .nav-link').forEach((a) => a.classList.toggle('active', a.dataset.id === id));
  const item = NAV.find((n) => n.id === id);
  $('#pageTitle').textContent = item ? item.label : 'QAMS';
  document.title = (item ? item.label + ' · ' : '') + 'QAMS';
}

async function route() {
  const [path, qstr = ''] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('?');
  const query = Object.fromEntries(new URLSearchParams(qstr));
  const [page, ...params] = path.split('/');
  const item = NAV.find((n) => n.id === page);
  charts.forEach((c) => c.destroy()); charts = [];
  $('#sidebar').classList.remove('show'); $('#backdrop').classList.remove('show');

  const view = $('#view');
  if (!Pages[page] || (item && !allowed(item))) { setActive(''); view.innerHTML = empty('Page not found or not permitted'); return; }
  setActive(page);
  view.innerHTML = loading();
  try { await Pages[page](view, params, query); }
  catch (e) { view.innerHTML = `<div class="alert alert-danger">${esc(e.message)}</div>`; }
}

// ---- notification bell ----
async function loadBell() {
  try {
    const { items, unread } = await API.get('/notifications');
    const c = $('#bellCount'); c.textContent = unread > 9 ? '9+' : unread; c.classList.toggle('d-none', !unread);
    $('#bellList').innerHTML = items.length ? items.map((n) => `
      <a href="#/requests/${n.request_id || ''}" data-nid="${n.id}" class="d-block px-3 py-2 border-bottom text-decoration-none text-body ${n.is_read ? '' : 'bg-primary-subtle'}">
        <div class="fw-semibold small">${esc(n.title)}</div>
        <div class="small text-secondary">${esc(n.message || '')}</div>
        <div class="small text-secondary opacity-75">${fmtDT(n.created_at)}</div></a>`).join('') : '<div class="p-3 text-secondary small">No notifications</div>';
    if (can('engineer', 'supervisor', 'qa_manager')) {
      const mine = await API.get('/requests/my-approvals');
      const b = $('#apprBadge'); if (b) { b.textContent = mine.length; b.classList.toggle('d-none', !mine.length); }
    }
  } catch (e) { /* silent: bell is non-critical */ }
}

function init() {
  if (!API.token()) return location.replace('index.html');
  const u = API.user();
  $('#topName').textContent = u.full_name; $('#topRole').textContent = `${u.email} · ${ROLE[u.role]}`;
  $('#sideUser').innerHTML = `<i class="bi bi-person-badge me-1"></i>${esc(u.full_name)}<br><span class="opacity-75">${ROLE[u.role]}</span>`;
  buildNav();

  $('#menuBtn').onclick = () => { $('#sidebar').classList.toggle('show'); $('#backdrop').classList.toggle('show'); };
  $('#backdrop').onclick = () => { $('#sidebar').classList.remove('show'); $('#backdrop').classList.remove('show'); };
  $('#logoutBtn').onclick = (e) => { e.preventDefault(); localStorage.removeItem('qams_token'); localStorage.removeItem('qams_user'); location.replace('index.html'); };

  const setThemeIcon = () => { $('#themeBtn i').className = 'bi bi-' + (document.documentElement.dataset.bsTheme === 'dark' ? 'sun' : 'moon-stars'); };
  setThemeIcon();
  $('#themeBtn').onclick = () => {
    const next = document.documentElement.dataset.bsTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.bsTheme = next; localStorage.setItem('qams_theme', next); setThemeIcon();
    Chart.defaults.color = next === 'dark' ? '#cbd5e1' : '#475569'; route(); // redraw charts with new colours
  };
  Chart.defaults.color = document.documentElement.dataset.bsTheme === 'dark' ? '#cbd5e1' : '#475569';

  $('#readAll').onclick = async (e) => { e.preventDefault(); await API.post('/notifications/read-all'); loadBell(); };
  $('#bellList').addEventListener('click', (e) => { const a = e.target.closest('[data-nid]'); if (a) { API.post(`/notifications/${a.dataset.nid}/read`).then(loadBell); } });
  $('#pwBtn').onclick = (e) => { e.preventDefault(); changePassword(); };

  window.addEventListener('hashchange', route);
  route(); loadBell(); setInterval(loadBell, 60000);
}

function changePassword() {
  const m = modal(`<div class="modal-header"><h5 class="modal-title">Change password</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
    <form class="modal-body"><div class="mb-3"><label class="form-label">Current password</label><input type="password" class="form-control" name="current" required></div>
    <div class="mb-3"><label class="form-label">New password (min 8 characters)</label><input type="password" class="form-control" name="next" minlength="8" required></div>
    <button class="btn btn-primary">Update</button></form>`);
  $('form', m).onsubmit = (e) => { e.preventDefault(); const f = e.target; busy($('button', f), async () => {
    await API.post('/auth/change-password', { current: f.current.value, next: f.next.value }); closeModal(); toast('Password updated'); }); };
}

document.addEventListener('DOMContentLoaded', init);
