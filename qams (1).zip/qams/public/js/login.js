// Login form handler (external file so the strict Content-Security-Policy can stay on).
if (localStorage.getItem('qams_token')) location.replace('app.html');
document.getElementById('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const err = document.getElementById('err'), btn = document.getElementById('btn');
  err.classList.add('d-none'); btn.disabled = true; btn.innerHTML = '<span class="spin"></span> Signing in...';
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: document.getElementById('email').value, password: document.getElementById('password').value }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Login failed');
    localStorage.setItem('qams_token', data.token);
    localStorage.setItem('qams_user', JSON.stringify(data.user));
    location.replace('app.html');
  } catch (ex) { err.textContent = ex.message; err.classList.remove('d-none'); btn.disabled = false; btn.textContent = 'Sign in'; }
});
