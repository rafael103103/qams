// Reports page: preview as a table, export to Excel / PDF.
Pages.reports = async (view) => {
  const customers = await API.get('/customers');
  const REPORTS = { status: 'Request Status Report', leadtime: 'Approval Lead Time Report', customer: 'Customer Report', monthly: 'Monthly Activity Report' };
  view.innerHTML = `
  <div class="card mb-3"><div class="card-body"><div class="row g-2 align-items-end">
    <div class="col-md-3"><label class="form-label">Report</label><select id="rt" class="form-select">${options(Object.entries(REPORTS).map(([v, label]) => ({ value: v, label })))}</select></div>
    <div class="col-md-2"><label class="form-label">From</label><input type="date" id="rf" class="form-control"></div>
    <div class="col-md-2"><label class="form-label">To</label><input type="date" id="rto" class="form-control"></div>
    <div class="col-md-3"><label class="form-label">Customer</label><select id="rc" class="form-select">${options(customers.map((c) => ({ value: c.id, label: c.name })), '', 'All customers')}</select></div>
    <div class="col-md-2 d-grid"><button class="btn btn-primary" id="rgo">Preview</button></div>
  </div>
  <div class="mt-3 d-flex gap-2"><button class="btn btn-success btn-sm" id="rx"><i class="bi bi-file-earmark-excel"></i> Export Excel</button>
    <button class="btn btn-danger btn-sm" id="rp"><i class="bi bi-file-earmark-pdf"></i> Export PDF</button></div></div></div>
  <div class="card" id="rout">${empty('Choose a report and press Preview')}</div>`;

  const qs = (fmt) => API.qs({ format: fmt, from: $('#rf').value, to: $('#rto').value, customer_id: $('#rc').value });
  $('#rgo').addEventListener('click', (e) => busy(e.currentTarget, async () => {
    const rep = await API.get(`/reports/${$('#rt').value}${qs('json')}`);
    $('#rout').innerHTML = `<div class="card-header">${esc(rep.title)} · ${rep.rows.length} rows</div>` + (rep.rows.length ? `<div class="table-responsive" style="max-height:60vh"><table class="table table-sm table-striped mb-0"><thead><tr>${rep.columns.map((c) => `<th>${esc(c.header)}</th>`).join('')}</tr></thead>
      <tbody>${rep.rows.map((r) => `<tr>${rep.columns.map((c) => `<td>${esc(r[c.key])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : empty('No data for the selected filters'));
  }));
  const exp = (fmt, ext) => (e) => busy(e.currentTarget, () => API.download(`/reports/${$('#rt').value}${qs(fmt)}`, `${$('#rt').value}_report.${ext}`));
  $('#rx').addEventListener('click', exp('xlsx', 'xlsx'));
  $('#rp').addEventListener('click', exp('pdf', 'pdf'));
};
