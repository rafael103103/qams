// Customers and Parts management (generic table + modal form).
function masterPage(cfg) {
  return async (view) => {
    const extra = cfg.load ? await cfg.load() : {};
    view.innerHTML = `
      <div class="d-flex gap-2 mb-3"><input id="mq" class="form-control" style="max-width:280px" placeholder="Search...">
        ${can(...cfg.writeRoles) ? `<button class="btn btn-accent ms-auto" id="mNew"><i class="bi bi-plus-lg"></i> Add ${cfg.single}</button>` : ''}</div>
      <div class="card" id="mt">${loading()}</div>`;
    let rows = [];
    const draw = () => {
      $('#mt').innerHTML = rows.length ? `<div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr>${cfg.cols.map((c) => `<th>${c.h}</th>`).join('')}<th></th></tr></thead><tbody>
        ${rows.map((r) => `<tr>${cfg.cols.map((c) => `<td>${c.v(r)}</td>`).join('')}<td class="text-end text-nowrap">
          ${can(...cfg.writeRoles) ? `<button class="btn btn-sm btn-outline-primary" data-e="${r.id}"><i class="bi bi-pencil"></i></button>` : ''}
          ${can('qa_manager') ? ` <button class="btn btn-sm btn-outline-danger" data-d="${r.id}"><i class="bi bi-trash"></i></button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : empty();
    };
    const load = async () => { rows = await API.get(cfg.api + API.qs({ q: $('#mq').value })); draw(); };
    $('#mq').addEventListener('input', debounce(load));

    const form = (r = {}) => {
      const m = modal(`<div class="modal-header"><h5 class="modal-title">${r.id ? 'Edit' : 'Add'} ${cfg.single}</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <form><div class="modal-body row g-3">${cfg.fields(r, extra)}</div><div class="modal-footer"><button class="btn btn-primary" data-busy="Saving...">Save</button></div></form>`);
      $('form', m).addEventListener('submit', (e) => { e.preventDefault(); busy($('button', e.target), async () => {
        const body = Object.fromEntries(new FormData(e.target));
        r.id ? await API.put(`${cfg.api}/${r.id}`, body) : await API.post(cfg.api, body);
        closeModal(); toast('Saved'); load(); }); });
    };
    $('#mNew')?.addEventListener('click', () => form());
    $('#mt').addEventListener('click', async (e) => {
      const ed = e.target.closest('[data-e]'), del = e.target.closest('[data-d]');
      if (ed) form(rows.find((r) => r.id === ed.dataset.e));
      if (del && confirmBox(`Delete this ${cfg.single}? This cannot be undone.`)) { try { await API.del(`${cfg.api}/${del.dataset.d}`); toast('Deleted'); load(); } catch (x) { toast(x.message, 'danger'); } }
    });
    load();
  };
}
const inp = (label, name, v, col = 6, extra = '') => `<div class="col-md-${col}"><label class="form-label">${label}</label><input class="form-control" name="${name}" value="${esc(v || '')}" ${extra}></div>`;

Pages.customers = masterPage({
  api: '/customers', single: 'customer', writeRoles: ['engineer', 'qa_manager'],
  cols: [{ h: 'Customer', v: (r) => `<b>${esc(r.name)}</b>` }, { h: 'Contact person', v: (r) => esc(r.contact_person || '-') }, { h: 'Email', v: (r) => esc(r.email || '-') }, { h: 'Remarks', v: (r) => esc(r.remarks || '') }],
  fields: (r) => inp('Customer name *', 'name', r.name, 12, 'required') + inp('Contact person', 'contact_person', r.contact_person) + inp('Email', 'email', r.email) +
    `<div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="2">${esc(r.remarks || '')}</textarea></div>`,
});

Pages.parts = masterPage({
  api: '/parts', single: 'part', writeRoles: ['engineer', 'supervisor', 'qa_manager'],
  load: async () => ({ customers: await API.get('/customers') }),
  cols: [{ h: 'Part number', v: (r) => `<b>${esc(r.part_number)}</b>` }, { h: 'Part name', v: (r) => esc(r.part_name) }, { h: 'Customer', v: (r) => esc(r.customer?.name || '-') },
    { h: 'Drawing no.', v: (r) => esc(r.drawing_number || '-') }, { h: 'Rev', v: (r) => esc(r.revision_number || '-') }, { h: 'Process', v: (r) => esc(r.process || '-') }],
  fields: (r, x) => inp('Part number *', 'part_number', r.part_number, 6, 'required') + inp('Part name *', 'part_name', r.part_name, 6, 'required') +
    `<div class="col-md-6"><label class="form-label">Customer</label><select class="form-select" name="customer_id">${options(x.customers.map((c) => ({ value: c.id, label: c.name })), r.customer_id, 'None')}</select></div>` +
    inp('Drawing number', 'drawing_number', r.drawing_number) + inp('Revision number', 'revision_number', r.revision_number) + inp('Process', 'process', r.process, 6, 'placeholder="e.g. Stamping, Machining, Plating"'),
});
