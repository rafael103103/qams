// AI Assistant page: six tools, each a form that calls /api/ai/*.
const AI_TOOLS = {
  email: { icon: 'envelope-paper', label: 'Email Writer', fields: `
    <label class="form-label">Email type</label><select class="form-select mb-2" name="kind">
      <option value="sample_submission">Sample Submission</option><option value="follow_up">Follow-up Request</option>
      <option value="ppap">PPAP Submission</option><option value="packaging">Packaging Approval</option><option value="customer">Customer Communication</option></select>
    <label class="form-label">Recipient</label><input class="form-control mb-2" name="recipient" placeholder="e.g. Mr. Tanaka (YAMAHA)">
    <label class="form-label">Tone</label><select class="form-select mb-2" name="tone"><option>polite and formal</option><option>friendly but professional</option><option>firm and urgent</option></select>
    <label class="form-label">Key details *</label><textarea class="form-control" name="details" rows="6" required placeholder="Part no., quantity, dates, what you need from them..."></textarea>` },
  grammar: { icon: 'spellcheck', label: 'Grammar Correction', fields: `<label class="form-label">Your text *</label><textarea class="form-control" name="text" rows="10" required></textarea>` },
  rephrase: { icon: 'arrow-repeat', label: 'Rephrase Tool', fields: `
    <label class="form-label">Target style</label><select class="form-select mb-2" name="tone"><option>professional business</option><option>concise and direct</option><option>polite and diplomatic</option></select>
    <label class="form-label">Casual text *</label><textarea class="form-control" name="text" rows="8" required placeholder="hey pls send the sample asap, customer is waiting"></textarea>` },
  capa: { icon: 'shield-check', label: 'CAPA Generator', fields: `
    <div class="row g-2 mb-2"><div class="col"><label class="form-label">Customer</label><input class="form-control" name="customer"></div><div class="col"><label class="form-label">Part number</label><input class="form-control" name="partNumber"></div></div>
    <label class="form-label">Problem description *</label><textarea class="form-control mb-2" name="problem" rows="5" required placeholder="What happened, quantity, where detected..."></textarea>
    <label class="form-label">Known root cause <span class="text-secondary small">(optional)</span></label><textarea class="form-control" name="rootCause" rows="2"></textarea>` },
  minutes: { icon: 'journal-text', label: 'Meeting Minutes', fields: `
    <div class="row g-2 mb-2"><div class="col-md-6"><label class="form-label">Title</label><input class="form-control" name="title"></div><div class="col-md-6"><label class="form-label">Date</label><input type="date" class="form-control" name="date"></div></div>
    <label class="form-label">Attendees</label><input class="form-control mb-2" name="attendees" placeholder="Comma separated">
    <label class="form-label">Raw notes *</label><textarea class="form-control" name="notes" rows="8" required></textarea>` },
  inspection: { icon: 'clipboard2-data', label: 'Inspection Summarizer', file: true, fields: `
    <label class="form-label">Upload report <span class="text-secondary small">(PDF, image, XLSX, CSV, TXT · max 4 MB)</span></label><input type="file" class="form-control mb-2" name="file" accept=".pdf,.png,.jpg,.jpeg,.xlsx,.csv,.txt,.tsv">
    <label class="form-label">...or paste results</label><textarea class="form-control mb-2" name="text" rows="6"></textarea>
    <label class="form-label">Extra instructions</label><input class="form-control" name="instructions" placeholder="e.g. focus on dimension B and hardness">` },
};

Pages.ai = async (view, params) => {
  const key = AI_TOOLS[params[0]] ? params[0] : 'email';
  const t = AI_TOOLS[key];
  view.innerHTML = `
  <ul class="nav nav-pills mb-3 flex-wrap gap-1">${Object.entries(AI_TOOLS).map(([k, v]) => `<li class="nav-item"><a class="nav-link ${k === key ? 'active' : ''}" href="#/ai/${k}"><i class="bi bi-${v.icon}"></i> ${v.label}</a></li>`).join('')}</ul>
  <div class="row g-3">
    <div class="col-lg-5"><div class="card"><div class="card-header"><i class="bi bi-${t.icon} text-accent"></i> ${t.label}</div>
      <form class="card-body" id="aiForm">${t.fields}<button class="btn btn-accent mt-3" data-busy="Generating..."><i class="bi bi-stars"></i> Generate</button></form></div></div>
    <div class="col-lg-7"><div class="card"><div class="card-header d-flex justify-content-between align-items-center">Result
      <div class="btn-group btn-group-sm"><button class="btn btn-outline-secondary" id="aiCopy"><i class="bi bi-clipboard"></i> Copy</button></div></div>
      <div class="card-body"><div class="ai-out" id="aiOut">Your result will appear here.</div>
      <div class="small text-secondary mt-2"><i class="bi bi-info-circle"></i> AI output can contain mistakes. Review before sending or filing.</div></div></div></div>
  </div>`;

  $('#aiForm').addEventListener('submit', (e) => {
    e.preventDefault();
    busy($('button', e.target), async () => {
      $('#aiOut').textContent = 'Thinking...';
      const fd = new FormData(e.target);
      try {
        const res = t.file ? await API.post('/ai/inspection', fd) : await API.post('/ai/' + key, Object.fromEntries(fd));
        $('#aiOut').textContent = res.result;
      } catch (err) { $('#aiOut').textContent = ''; throw err; }
    });
  });
  $('#aiCopy').addEventListener('click', () => navigator.clipboard.writeText($('#aiOut').textContent).then(() => toast('Copied')));
};
