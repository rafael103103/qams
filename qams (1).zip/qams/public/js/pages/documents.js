// Document repository: upload, search, download, version history.
Pages.documents = async (view) => {
  const customers = await API.get('/customers');
  view.innerHTML = `
    <div class="d-flex flex-wrap gap-2 mb-3">
      <input id="dq" class="form-control" style="max-width:260px" placeholder="Search title / doc no...">
      <select id="dc" class="form-select" style="max-width:200px">${options(DOC_CATS, '', 'All categories')}</select>
      <button class="btn btn-accent ms-auto" id="dNew"><i class="bi bi-upload"></i> Upload document</button></div>
    <div class="card" id="dt">${loading()}</div>`;
  let rows = [];
  const draw = () => { $('#dt').innerHTML = rows.length ? `<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Title</th><th>Doc no.</th><th>Category</th><th>Customer</th><th>Ver.</th><th>Updated</th><th></th></tr></thead><tbody>
    ${rows.map((d) => `<tr><td><b>${esc(d.title)}</b></td><td>${esc(d.doc_number || '-')}</td><td><span class="badge text-bg-secondary">${esc(d.category)}</span></td><td>${esc(d.customer?.name || '-')}</td><td>v${d.current_version}</td><td>${fmtDate(d.updated_at)}</td>
      <td class="text-end text-nowrap"><button class="btn btn-sm btn-outline-primary" data-vers="${d.id}" title="Versions / download"><i class="bi bi-clock-history"></i></button>
      <button class="btn btn-sm btn-outline-success" data-newv="${d.id}" title="Upload new version"><i class="bi bi-file-earmark-plus"></i></button>
      ${can('qa_manager') ? `<button class="btn btn-sm btn-outline-danger" data-del="${d.id}"><i class="bi bi-trash"></i></button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : empty('No documents found'); };
  const load = async () => { rows = await API.get('/documents' + API.qs({ q: $('#dq').value, category: $('#dc').value })); draw(); };
  $('#dq').addEventListener('input', debounce(load)); $('#dc').addEventListener('change', load);

  $('#dNew').addEventListener('click', () => {
    const m = modal(`<div class="modal-header"><h5 class="modal-title">Upload document</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <form><div class="modal-body row g-3">
        <div class="col-12"><label class="form-label">Title *</label><input class="form-control" name="title" required></div>
        <div class="col-md-6"><label class="form-label">Category *</label><select class="form-select" name="category" required>${options(DOC_CATS)}</select></div>
        <div class="col-md-6"><label class="form-label">Document no.</label><input class="form-control" name="doc_number"></div>
        <div class="col-12"><label class="form-label">Customer</label><select class="form-select" name="customer_id">${options(customers.map((c) => ({ value: c.id, label: c.name })), '', 'None')}</select></div>
        <div class="col-12"><label class="form-label">File * <span class="small text-secondary">(max 4 MB)</span></label><input type="file" class="form-control" name="file" required></div>
      </div><div class="modal-footer"><button class="btn btn-primary" data-busy="Uploading...">Upload</button></div></form>`);
    $('form', m).addEventListener('submit', (e) => { e.preventDefault(); busy($('button', e.target), async () => { await API.post('/documents', new FormData(e.target)); closeModal(); toast('Uploaded'); load(); }); });
  });

  $('#dt').addEventListener('click', async (e) => {
    const v = e.target.closest('[data-vers]'), n = e.target.closest('[data-newv]'), del = e.target.closest('[data-del]');
    if (v) {
      const list = await API.get(`/documents/${v.dataset.vers}/versions`);
      const m = modal(`<div class="modal-header"><h5 class="modal-title">Version history</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body p-0"><ul class="list-group list-group-flush">${list.map((x) => `<li class="list-group-item d-flex justify-content-between align-items-center">
          <div><b>v${x.version_no}</b> · ${esc(x.file_name)}<div class="small text-secondary">${fmtDT(x.created_at)} · ${esc(x.uploader?.full_name || '')}${x.change_note ? ' · ' + esc(x.change_note) : ''}</div></div>
          <button class="btn btn-sm btn-primary" data-dl="${x.id}"><i class="bi bi-download"></i></button></li>`).join('')}</ul></div>`);
      m.addEventListener('click', (ev) => { const b = ev.target.closest('[data-dl]'); if (b) openFile(`/documents/versions/${b.dataset.dl}/url`).catch((x) => toast(x.message, 'danger')); });
    }
    if (n) {
      const m = modal(`<div class="modal-header"><h5 class="modal-title">Upload new version</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
        <form><div class="modal-body"><div class="mb-3"><label class="form-label">File *</label><input type="file" class="form-control" name="file" required></div>
        <div><label class="form-label">What changed?</label><input class="form-control" name="change_note"></div></div><div class="modal-footer"><button class="btn btn-primary" data-busy="Uploading...">Upload</button></div></form>`);
      $('form', m).addEventListener('submit', (ev) => { ev.preventDefault(); busy($('button', ev.target), async () => { await API.post(`/documents/${n.dataset.newv}/versions`, new FormData(ev.target)); closeModal(); toast('New version uploaded'); load(); }); });
    }
    if (del && confirmBox('Delete this document and ALL its versions?')) { try { await API.del('/documents/' + del.dataset.del); toast('Deleted'); load(); } catch (x) { toast(x.message, 'danger'); } }
  });
  load();
};
