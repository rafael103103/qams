// Approval requests: list, create/edit form, detail with workflow actions.
Pages.requests = async (view, params, query = {}) => {
  if (params[0] === 'new') return requestForm(view);
  if (params[0] && params[1] === 'edit') return requestForm(view, params[0]);
  if (params[0]) return requestDetail(view, params[0]);
  return requestList(view, query);
};

Pages.approvals = async (view) => {
  const rows = await API.get('/requests/my-approvals');
  view.innerHTML = `<div class="card"><div class="card-header">Waiting for my approval (${rows.length})</div>${requestTable(rows)}</div>`;
  bindRows(view);
};

function requestTable(rows) {
  if (!rows.length) return empty('No requests found');
  return `<div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr>
    <th>Request No.</th><th>Type</th><th>Customer</th><th>Part No.</th><th>Requestor</th><th>Target</th><th>Level</th><th>Status</th></tr></thead><tbody>
    ${rows.map((r) => `<tr data-id="${r.id}"><td class="fw-semibold">${esc(r.request_no)}</td><td>${esc(r.type)}</td><td>${esc(r.customer?.name || '-')}</td>
      <td>${esc(r.part_number || '-')}</td><td>${esc(r.requestor?.full_name || '')}</td>
      <td class="${isOverdue(r) ? 'text-danger fw-bold' : ''}">${fmtDate(r.target_date)}${isOverdue(r) ? ' <i class="bi bi-exclamation-triangle-fill"></i>' : ''}</td>
      <td>${r.current_level ? 'L' + r.current_level : '-'}</td><td>${badge(r.status)}</td></tr>`).join('')}</tbody></table></div>`;
}
function bindRows(root) { root.addEventListener('click', (e) => { const tr = e.target.closest('tr[data-id]'); if (tr) location.hash = '#/requests/' + tr.dataset.id; }); }

async function requestList(view, query) {
  const customers = await API.get('/customers');
  view.innerHTML = `
    <div class="d-flex flex-wrap gap-2 mb-3">
      <input id="fq" class="form-control" style="max-width:240px" placeholder="Search no. / part..." value="${esc(query.q || '')}">
      <select id="fs" class="form-select" style="max-width:160px">${options(['Pending', 'For Approval', 'Returned', 'Approved', 'Rejected', 'Completed'], query.status, 'All statuses')}</select>
      <select id="ft" class="form-select" style="max-width:200px">${options(REQ_TYPES, query.type, 'All types')}</select>
      <select id="fc" class="form-select" style="max-width:180px">${options(customers.map((c) => ({ value: c.id, label: c.name })), query.customer_id, 'All customers')}</select>
      <div class="form-check form-switch align-self-center"><input class="form-check-input" type="checkbox" id="fo" ${query.overdue ? 'checked' : ''}><label class="form-check-label" for="fo">Overdue only</label></div>
      <a href="#/requests/new" class="btn btn-accent ms-auto"><i class="bi bi-plus-lg"></i> New request</a>
    </div>
    <div class="card" id="tbl">${loading()}</div>`;
  const load = async () => {
    const qs = API.qs({ q: $('#fq').value, status: $('#fs').value, type: $('#ft').value, customer_id: $('#fc').value, overdue: $('#fo').checked ? '1' : '' });
    const rows = await API.get('/requests' + qs);
    $('#tbl').innerHTML = requestTable(rows);
  };
  ['#fs', '#ft', '#fc', '#fo'].forEach((s) => $(s).addEventListener('change', load));
  $('#fq').addEventListener('input', debounce(load));
  bindRows($('#tbl'));
  load();
}

async function requestForm(view, id) {
  const [customers, parts, dir, existing] = await Promise.all([
    API.get('/customers'), API.get('/parts'), API.get('/users/directory'), id ? API.get('/requests/' + id) : null]);
  const r = existing?.request || { request_date: new Date().toISOString().slice(0, 10) };
  const stepApprover = (role) => existing?.steps.find((s) => s.role === role)?.approver_id || '';
  const approverSel = (role, label) => `<div class="col-md-4"><label class="form-label">${label} <span class="text-secondary small">(optional)</span></label>
    <select class="form-select" name="ap_${role}">${options(dir.filter((u) => u.role === role).map((u) => ({ value: u.id, label: u.full_name })), stepApprover(role), 'Anyone with this role')}</select></div>`;

  view.innerHTML = `
  <div class="card"><div class="card-header">${id ? 'Edit ' + esc(r.request_no) : 'New approval request'}</div>
  <form class="card-body" id="rf"><div class="row g-3">
    <div class="col-md-4"><label class="form-label">Date</label><input type="date" class="form-control" name="request_date" value="${r.request_date || ''}" required></div>
    <div class="col-md-4"><label class="form-label">Category / Type *</label><select class="form-select" name="type" required>${options(REQ_TYPES, r.type, 'Select...')}</select></div>
    <div class="col-md-4"><label class="form-label">Target date</label><input type="date" class="form-control" name="target_date" value="${r.target_date || ''}"></div>
    <div class="col-md-4"><label class="form-label">Customer *</label><select class="form-select" name="customer_id" id="rc" required>${options(customers.map((c) => ({ value: c.id, label: c.name })), r.customer_id, 'Select...')}</select></div>
    <div class="col-md-4"><label class="form-label">Part number *</label><input class="form-control" name="part_number" id="rpn" list="partList" value="${esc(r.part_number || '')}" placeholder="Type or pick from list" required>
      <datalist id="partList"></datalist></div>
    <div class="col-md-4"><label class="form-label">Part name</label><input class="form-control" name="part_name" id="rpname" value="${esc(r.part_name || '')}"></div>
    <div class="col-12"><label class="form-label">Description *</label><textarea class="form-control" name="description" rows="3" required>${esc(r.description || '')}</textarea></div>
    <div class="col-12"><label class="form-label">Reason</label><textarea class="form-control" name="reason" rows="2">${esc(r.reason || '')}</textarea></div>
    ${approverSel('engineer', 'Level 1 · Engineer')}${approverSel('supervisor', 'Level 2 · Section Head')}${approverSel('qa_manager', 'Level 3 · QA Manager')}
    <div class="col-12"><label class="form-label">Attachments <span class="text-secondary small">(max 4 MB each)</span></label><input type="file" class="form-control" id="rfiles" multiple></div>
    ${existing?.attachments.length ? `<div class="col-12 small">Existing: ${existing.attachments.map((a) => esc(a.file_name)).join(', ')}</div>` : ''}
  </div>
  <div class="mt-4 d-flex gap-2 flex-wrap">
    <button class="btn btn-primary" data-act="save" data-busy="Saving...">Save as draft</button>
    <button class="btn btn-accent" data-act="submit" data-busy="Submitting...">${r.status === 'Returned' ? 'Save &amp; resubmit' : 'Save &amp; submit for approval'}</button>
    <a class="btn btn-outline-secondary" href="#/requests${id ? '/' + id : ''}">Cancel</a>
  </div></form></div>`;

  const fillParts = () => { $('#partList').innerHTML = parts.filter((p) => !$('#rc').value || p.customer_id === $('#rc').value).map((p) => `<option value="${esc(p.part_number)}">${esc(p.part_name)}</option>`).join(''); };
  fillParts(); $('#rc').addEventListener('change', fillParts);
  $('#rpn').addEventListener('change', () => { const p = parts.find((x) => x.part_number === $('#rpn').value); if (p && !$('#rpname').value) $('#rpname').value = p.part_name; });

  let action = 'save';
  $$('button[data-act]', view).forEach((b) => b.addEventListener('click', () => (action = b.dataset.act)));
  $('#rf').addEventListener('submit', (e) => {
    e.preventDefault();
    busy($(`button[data-act="${action}"]`, view), async () => {
      const f = e.target, fd = Object.fromEntries(new FormData(f));
      const body = { ...fd, approvers: { engineer: fd.ap_engineer, supervisor: fd.ap_supervisor, qa_manager: fd.ap_qa_manager } };
      ['ap_engineer', 'ap_supervisor', 'ap_qa_manager'].forEach((k) => delete body[k]);
      const p = parts.find((x) => x.part_number === body.part_number && x.customer_id === body.customer_id);
      if (p) body.part_id = p.id;
      const saved = id ? await API.put('/requests/' + id, body) : await API.post('/requests', body);
      const files = $('#rfiles').files;
      if (files.length) { const up = new FormData(); [...files].forEach((x) => up.append('files', x)); await API.post(`/requests/${saved.id}/attachments`, up); }
      if (action === 'submit') await API.post(`/requests/${saved.id}/submit`);
      toast(action === 'submit' ? 'Submitted for approval' : 'Draft saved');
      location.hash = '#/requests/' + saved.id;
    });
  });
}

async function requestDetail(view, id) {
  const { request: r, steps, history, attachments } = await API.get('/requests/' + id);
  const stepCard = (s) => `<div class="stp ${s.status}">
      <div class="small text-secondary">Level ${s.level}</div><div class="fw-semibold">${ROLE[s.role]}</div>
      <div class="small">${esc(s.approver?.full_name || 'Any ' + ROLE[s.role])}</div>
      <div class="mt-1">${s.status === 'Waiting' ? '<span class="badge text-bg-secondary">Waiting</span>' : s.status === 'Pending' ? '<span class="badge text-bg-warning">Awaiting decision</span>' : badge(s.status)}</div>
      ${s.acted_at ? `<div class="small text-secondary mt-1">${esc(s.actor?.full_name || '')}<br>${fmtDT(s.acted_at)}</div>` : ''}</div>`;
  const row = (k, v) => `<div class="col-sm-6 col-lg-4"><div class="small text-secondary">${k}</div><div class="fw-semibold">${v || '-'}</div></div>`;

  view.innerHTML = `
  <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
    <a href="#/requests" class="btn btn-light"><i class="bi bi-arrow-left"></i></a>
    <h4 class="mb-0">${esc(r.request_no)}</h4>${badge(r.status)}${isOverdue(r) ? '<span class="badge text-bg-danger">Overdue</span>' : ''}
    <div class="ms-auto d-flex gap-2">
      ${r.can_edit ? `<a class="btn btn-outline-primary" href="#/requests/${r.id}/edit"><i class="bi bi-pencil"></i> Edit</a><button class="btn btn-accent" id="bSubmit" data-busy="Submitting..."><i class="bi bi-send"></i> ${r.status === 'Returned' ? 'Resubmit' : 'Submit for approval'}</button>` : ''}
      ${r.can_complete ? '<button class="btn btn-primary" id="bComplete"><i class="bi bi-flag"></i> Mark completed</button>' : ''}
    </div>
  </div>

  <div class="card mb-3"><div class="card-body"><div class="row g-3">
    ${row('Type', esc(r.type))}${row('Date', fmtDate(r.request_date))}${row('Target date', fmtDate(r.target_date))}
    ${row('Customer', esc(r.customer?.name))}${row('Part number', esc(r.part_number))}${row('Part name', esc(r.part_name))}
    ${row('Requestor', esc(r.requestor?.full_name))}${row('Submitted', fmtDT(r.submitted_at))}${row('Closed', fmtDT(r.closed_at))}
    <div class="col-12"><div class="small text-secondary">Description</div><div style="white-space:pre-wrap">${esc(r.description)}</div></div>
    <div class="col-12"><div class="small text-secondary">Reason</div><div style="white-space:pre-wrap">${esc(r.reason) || '-'}</div></div>
  </div></div></div>

  <div class="card mb-3"><div class="card-header">Approval route</div><div class="card-body"><div class="route">${steps.map(stepCard).join('<div class="align-self-center text-secondary d-none d-md-block"><i class="bi bi-chevron-right"></i></div>')}</div></div></div>

  ${r.can_act ? `<div class="card mb-3 border-warning"><div class="card-header bg-warning-subtle">Your decision (Level ${r.current_level})</div><div class="card-body">
    <textarea id="aComment" class="form-control mb-3" rows="3" placeholder="Comments (required to reject or return)"></textarea>
    <div class="d-flex flex-wrap gap-2">
      <button class="btn btn-success" data-a="approve"><i class="bi bi-check-lg"></i> Approve</button>
      <button class="btn btn-warning" data-a="return"><i class="bi bi-arrow-counterclockwise"></i> Return for revision</button>
      <button class="btn btn-danger" data-a="reject"><i class="bi bi-x-lg"></i> Reject</button></div></div></div>` : ''}

  <div class="row g-3">
    <div class="col-lg-7"><div class="card h-100"><div class="card-header">Electronic approval history</div><div class="card-body">
      ${history.length ? `<div class="timeline">${history.map((h) => `<div class="ev ${h.action}"><div><b>${esc(h.action)}</b>${h.level ? ` · Level ${h.level}` : ''} <span class="text-secondary">by ${esc(h.user_name)} (${esc(h.user_role || '')})</span></div>
        <div class="small text-secondary">${fmtDT(h.created_at)}</div>${h.comment ? `<div class="mt-1 p-2 rounded" style="background:var(--q-bg)">${esc(h.comment)}</div>` : ''}</div>`).join('')}</div>` : empty('No activity yet')}
      <div class="input-group mt-3"><input id="cText" class="form-control" placeholder="Add a comment..."><button class="btn btn-outline-primary" id="cBtn">Post</button></div>
    </div></div></div>
    <div class="col-lg-5"><div class="card h-100"><div class="card-header">Attachments</div>
      <ul class="list-group list-group-flush">${attachments.length ? attachments.map((a) => `<li class="list-group-item bg-transparent d-flex justify-content-between align-items-center">
        <a href="#" data-dl="${a.id}"><i class="bi bi-paperclip"></i> ${esc(a.file_name)}</a>
        <span class="small text-secondary">${a.size_bytes ? (a.size_bytes / 1024).toFixed(0) + ' KB' : ''}</span></li>`).join('') : '<li class="list-group-item bg-transparent text-secondary">No attachments</li>'}</ul></div></div>
  </div>`;

  $('#bSubmit')?.addEventListener('click', (e) => busy(e.currentTarget, async () => { await API.post(`/requests/${id}/submit`); toast('Submitted for approval'); route(); }));
  $('#bComplete')?.addEventListener('click', () => { if (confirmBox('Mark this request as completed?')) API.post(`/requests/${id}/complete`, {}).then(() => { toast('Completed'); route(); }).catch((e) => toast(e.message, 'danger')); });
  $$('[data-a]', view).forEach((b) => b.addEventListener('click', () => {
    const a = b.dataset.a, comment = $('#aComment').value.trim();
    if (a !== 'approve' && !comment) return toast('Please enter a comment first', 'warning');
    if (!confirmBox(`Confirm: ${a.toUpperCase()} this request?`)) return;
    busy(b, async () => { await API.post(`/requests/${id}/action`, { action: a, comment }); toast('Decision recorded'); route(); });
  }));
  $('#cBtn').addEventListener('click', () => { const t = $('#cText').value.trim(); if (t) API.post(`/requests/${id}/comment`, { comment: t }).then(route).catch((e) => toast(e.message, 'danger')); });
  $$('[data-dl]', view).forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); openFile(`/requests/${id}/attachments/${a.dataset.dl}/url`).catch((x) => toast(x.message, 'danger')); }));
}
