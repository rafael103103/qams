// Dashboard page.
Pages.dashboard = async (view) => {
  const d = await API.get('/dashboard');
  const c = d.counts;
  const kpi = (icon, bg, num, label, href) => `<div class="col-6 col-xl-3"><a href="${href}" class="text-decoration-none text-body"><div class="card kpi"><div class="ico ${bg}"><i class="bi bi-${icon}"></i></div><div><div class="num">${num}</div><div class="lbl">${label}</div></div></div></a></div>`;

  view.innerHTML = `
    <div class="row g-3 mb-3">
      ${kpi('hourglass-split', 'bg-q-warn', c.pending + c.forApproval, 'Pending Requests', '#/requests?status=For Approval')}
      ${kpi('check-circle', 'bg-q-ok', c.approved, 'Approved Requests', '#/requests?status=Approved')}
      ${kpi('x-circle', 'bg-q-bad', c.rejected, 'Rejected Requests', '#/requests?status=Rejected')}
      ${kpi('alarm', 'bg-q-pri', c.overdue, 'Overdue Requests', '#/requests?overdue=1')}
    </div>
    <div class="row g-3">
      <div class="col-lg-8"><div class="card h-100"><div class="card-header">Monthly submission trend</div><div class="card-body"><div class="chart-box"><canvas id="cTrend"></canvas></div></div></div></div>
      <div class="col-lg-4"><div class="card h-100"><div class="card-header">Customer statistics</div><div class="card-body"><div class="chart-box"><canvas id="cCust"></canvas></div></div></div></div>
      <div class="col-lg-8"><div class="card h-100"><div class="card-header d-flex justify-content-between"><span>Approval lead time (days)</span><span class="text-secondary small">Overall avg: <b>${d.leadTime.overall}</b> days</span></div><div class="card-body"><div class="chart-box"><canvas id="cLead"></canvas></div></div></div></div>
      <div class="col-lg-4"><div class="card h-100"><div class="card-header">Recent activity</div><div class="list-group list-group-flush" id="recent">${loading()}</div></div></div>
    </div>`;

  const short = (m) => { const [y, mo] = m.split('-'); return new Date(y, mo - 1).toLocaleString(undefined, { month: 'short' }) + " '" + y.slice(2); };
  const mk = (id, cfg) => { const ch = new Chart(document.getElementById(id), { ...cfg, options: { responsive: true, maintainAspectRatio: false, ...cfg.options } }); charts.push(ch); };

  mk('cTrend', { type: 'bar', data: { labels: d.trend.labels.map(short), datasets: [{ label: 'Submitted', data: d.trend.data, backgroundColor: '#0F4C81', borderRadius: 6 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
  mk('cLead', { type: 'line', data: { labels: d.leadTime.labels.map(short), datasets: [{ label: 'Avg days', data: d.leadTime.data, borderColor: '#1ABC9C', backgroundColor: 'rgba(26,188,156,.15)', fill: true, tension: .35 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } } });
  mk('cCust', { type: 'doughnut', data: { labels: d.customers.map((x) => x.name), datasets: [{ data: d.customers.map((x) => x.count), backgroundColor: ['#0F4C81', '#1ABC9C', '#f59e0b', '#6366f1', '#ef4444', '#14b8a6', '#8b5cf6', '#ec4899', '#64748b', '#84cc16'] }] },
    options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 12 } } } } });

  const recent = (await API.get('/requests')).slice(0, 6);
  $('#recent').innerHTML = recent.length ? recent.map((r) => `<a class="list-group-item list-group-item-action bg-transparent" href="#/requests/${r.id}">
    <div class="d-flex justify-content-between"><b>${esc(r.request_no)}</b>${badge(r.status)}</div>
    <div class="small text-secondary">${esc(r.type)} · ${esc(r.customer?.name || '-')}</div></a>`).join('') : empty('No requests yet');
};
