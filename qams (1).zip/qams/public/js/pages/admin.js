// Administration: users and audit trail.
Pages.users = async (view) => {
  let rows = [];
  view.innerHTML = `<div class="d-flex mb-3"><button class="btn btn-accent ms-auto" id="uNew"><i class="bi bi-person-plus"></i> Add user</button></div><div class="card" id="ut">${loading()}</div>`;
  const draw = () => { $('#ut').innerHTML = `<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Status</th><th></th></tr></thead><tbody>
    ${rows.map((u) => `<tr><td><b>${esc(u.full_name)}</b></td><td>${esc(u.email)}</td><td>${ROLE[u.role]}</td><td>${esc(u.department || '-')}</td>
      <td>${u.is_active ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Disabled</span>'}</td>
      <td class="text-end"><button class="btn btn-sm btn-outline-primary" data-e="${u.id}"><i class="bi bi-pencil"></i></button></td></tr>`).join('')}</tbody></table></div>`; };
  const load = async () => { rows = await API.get('/users'); draw(); };

  const form = (u = {}) => {
    const m = modal(`<div class="modal-header"><h5 class="modal-title">${u.id ? 'Edit' : 'Add'} user</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
      <form><div class="modal-body row g-3">
        ${inp('Full name *', 'full_name', u.full_name, 12, 'required')}
        ${u.id ? '' : inp('Email *', 'email', '', 12, 'type="email" required')}
        <div class="col-md-6"><label class="form-label">Role *</label><select class="form-select" name="role">${options(Object.entries(ROLE).map(([v, label]) => ({ value: v, label })), u.role || 'requestor')}</select></div>
        ${inp('Department', 'department', u.department)}
        <div class="col-12"><label class="form-label">${u.id ? 'New password (leave blank to keep)' : 'Password * (min 8)'}</label><input type="password" class="form-control" name="password" minlength="8" ${u.id ? '' : 'required'} autocomplete="new-password"></div>
        ${u.id ? `<div class="col-12 form-check form-switch ms-2"><input class="form-check-input" type="checkbox" name="is_active" id="ua" ${u.is_active ? 'checked' : ''}><label class="form-check-label" for="ua">Account active</label></div>` : ''}
      </div><div class="modal-footer"><button class="btn btn-primary" data-busy="Saving...">Save</button></div></form>`);
    $('form', m).addEventListener('submit', (e) => { e.preventDefault(); busy($('button', e.target), async () => {
      const fd = Object.fromEntries(new FormData(e.target));
      if (!fd.password) delete fd.password;
      if (u.id) fd.is_active = $('#ua').checked;
      u.id ? await API.put('/users/' + u.id, fd) : await API.post('/users', fd);
      closeModal(); toast('Saved'); load(); }); });
  };
  $('#uNew').addEventListener('click', () => form());
  $('#ut').addEventListener('click', (e) => { const b = e.target.closest('[data-e]'); if (b) form(rows.find((r) => r.id === b.dataset.e)); });
  load();
};

Pages.audit = async (view) => {
  view.innerHTML = `
  <div class="d-flex flex-wrap gap-2 mb-3">
    <input id="au" class="form-control" style="max-width:200px" placeholder="User name...">
    <select id="ae" class="form-select" style="max-width:180px">${options(['request', 'customer', 'part', 'user', 'document', 'request_attachment'], '', 'All entities')}</select>
    <input id="af" type="date" class="form-control" style="max-width:160px"><input id="at" type="date" class="form-control" style="max-width:160px">
    <button class="btn btn-primary" id="ag">Filter</button></div>
  <div class="card" id="aout">${loading()}</div>`;
  const load = async () => {
    const rows = await API.get('/audit' + API.qs({ user: $('#au').value, entity: $('#ae').value, from: $('#af').value, to: $('#at').value }));
    const j = (o) => (o && Object.keys(o).length ? `<code class="small" style="white-space:pre-wrap">${esc(JSON.stringify(o, null, 1))}</code>` : '-');
    $('#aout').innerHTML = rows.length ? `<div class="table-responsive"><table class="table table-sm align-top mb-0"><thead><tr><th>Date / time</th><th>User</th><th>Action</th><th>Entity</th><th>Old value</th><th>New value</th></tr></thead><tbody>
      ${rows.map((r) => `<tr><td class="text-nowrap">${fmtDT(r.created_at)}</td><td>${esc(r.user_name || '-')}</td><td><span class="badge text-bg-secondary">${esc(r.action)}</span></td>
        <td>${esc(r.entity)}<div class="small text-secondary">${esc(r.entity_id || '')}</div></td><td>${j(r.old_value)}</td><td>${j(r.new_value)}</td></tr>`).join('')}</tbody></table></div>` : empty('No audit records');
  };
  $('#ag').addEventListener('click', load); load();
};
