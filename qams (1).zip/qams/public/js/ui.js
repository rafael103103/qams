// Shared UI helpers.
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = (d) => (d ? new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: '2-digit' }) : '-');
const fmtDT = (d) => (d ? new Date(d).toLocaleString(undefined, { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '-');
const ROLE = { requestor: 'Requestor', engineer: 'Engineer', supervisor: 'Supervisor', qa_manager: 'QA Manager', admin: 'Administrator' };
const REQ_TYPES = ['PPAP Approval', 'Sample Submission', 'Packaging Approval', 'Limit Sample Approval', 'Engineering Change', '4M Change', 'Process Change Request', 'Deviation Request', 'Trial Request'];
const DOC_CATS = ['PPAP Documents', 'Packaging Standards', 'Inspection Reports', 'Customer Drawings', 'Control Plans', 'QCPC', 'Other'];

const badge = (s) => `<span class="badge badge-status st-${esc(s)}">${esc(s)}</span>`;
const isOverdue = (r) => ['Pending', 'For Approval', 'Returned'].includes(r.status) && r.target_date && r.target_date < new Date().toISOString().slice(0, 10);
const can = (...roles) => { const u = API.user(); return u.role === 'admin' || roles.includes(u.role); };
const options = (arr, sel, ph) => (ph ? `<option value="">${ph}</option>` : '') + arr.map((o) => { const v = o.value ?? o, l = o.label ?? o; return `<option value="${esc(v)}" ${v === sel ? 'selected' : ''}>${esc(l)}</option>`; }).join('');

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast align-items-center text-bg-${type} border-0`;
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(msg)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  $('#toasts').appendChild(el);
  const t = new bootstrap.Toast(el, { delay: 4000 }); t.show();
  el.addEventListener('hidden.bs.toast', () => el.remove());
}

/** Show a Bootstrap modal with arbitrary HTML. Returns the modal element. */
function modal(html, size) {
  $('#modal .modal-dialog').className = 'modal-dialog modal-dialog-scrollable' + (size ? ' modal-' + size : '');
  $('#modalContent').innerHTML = html;
  const m = bootstrap.Modal.getOrCreateInstance('#modal'); m.show();
  return $('#modalContent');
}
const closeModal = () => bootstrap.Modal.getInstance('#modal')?.hide();

/** Wrap an async click handler: disables the button and shows a spinner. */
async function busy(btn, fn) {
  const html = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spin"></span> ' + (btn.dataset.busy || 'Working...');
  try { return await fn(); } catch (e) { toast(e.message, 'danger'); } finally { btn.disabled = false; btn.innerHTML = html; }
}

const confirmBox = (msg) => confirm(msg);
const loading = () => '<div class="text-center text-secondary py-5"><span class="spin"></span> Loading...</div>';
const empty = (m = 'Nothing here yet') => `<div class="text-center text-secondary py-5"><i class="bi bi-inbox fs-1 d-block mb-2"></i>${esc(m)}</div>`;

/** Reusable debounced input binder */
function debounce(fn, ms = 300) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

/** Open a signed file URL returned by the API. */
async function openFile(path) { const { url } = await API.get(path); window.open(url, '_blank', 'noopener'); }
