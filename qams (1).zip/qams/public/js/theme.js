// Apply the saved theme before first paint (avoids a light flash in dark mode).
(function () {
  try { document.documentElement.setAttribute('data-bs-theme', localStorage.getItem('qams_theme') || 'light'); } catch (e) {}
})();
