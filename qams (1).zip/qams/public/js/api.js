// Thin fetch wrapper: attaches the JWT, handles 401 (session expired) and errors uniformly.
const API = {
  token: () => localStorage.getItem('qams_token'),
  user: () => JSON.parse(localStorage.getItem('qams_user') || 'null'),

  async request(method, url, body, opts = {}) {
    const headers = { Authorization: 'Bearer ' + API.token() };
    let payload;
    if (body instanceof FormData) payload = body;
    else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
    const res = await fetch('/api' + url, { method, headers, body: payload });
    if (res.status === 401) { localStorage.removeItem('qams_token'); location.replace('index.html'); throw new Error('Session expired'); }
    if (opts.blob) { if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Download failed'); return res.blob(); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  },
  get: (u) => API.request('GET', u),
  post: (u, b) => API.request('POST', u, b ?? {}),
  put: (u, b) => API.request('PUT', u, b),
  del: (u) => API.request('DELETE', u),
  qs: (o) => { const p = new URLSearchParams(); Object.entries(o).forEach(([k, v]) => v && p.append(k, v)); const s = p.toString(); return s ? '?' + s : ''; },

  /** Download a generated file (report) through the authenticated API. */
  async download(url, filename) {
    const blob = await API.request('GET', url, undefined, { blob: true });
    const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: filename });
    document.body.appendChild(a); a.click(); a.remove();
  },
};
