-- =====================================================================
-- QAMS - Quality & Engineering Approval Management System
-- Supabase PostgreSQL schema.  Run in: Supabase Dashboard > SQL Editor
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- ENUM-like domains (CHECK constraints keep it easy to extend) ----------

-- ---------- USERS ----------
create table if not exists users (
  id            uuid primary key default gen_random_uuid(),
  full_name     text        not null,
  email         text        not null unique,
  password_hash text        not null,
  role          text        not null check (role in ('requestor','engineer','supervisor','qa_manager','admin')),
  department    text,
  is_active     boolean     not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------- CUSTOMERS ----------
create table if not exists customers (
  id              uuid primary key default gen_random_uuid(),
  name            text not null unique,
  contact_person  text,
  email           text,
  remarks         text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ---------- PARTS ----------
create table if not exists parts (
  id              uuid primary key default gen_random_uuid(),
  part_number     text not null unique,
  part_name       text not null,
  customer_id     uuid references customers(id) on delete set null,
  drawing_number  text,
  revision_number text,
  process         text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists idx_parts_customer on parts(customer_id);

-- ---------- REQUEST NUMBER SEQUENCE ----------
create sequence if not exists request_no_seq start 1;

create or replace function set_request_no() returns trigger as $$
begin
  if new.request_no is null or new.request_no = '' then
    new.request_no := 'REQ-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('request_no_seq')::text, 5, '0');
  end if;
  return new;
end $$ language plpgsql;

-- ---------- APPROVAL REQUESTS ----------
create table if not exists requests (
  id             uuid primary key default gen_random_uuid(),
  request_no     text unique,
  request_date   date not null default current_date,
  type           text not null check (type in (
                   'PPAP Approval','Sample Submission','Packaging Approval','Limit Sample Approval',
                   'Engineering Change','4M Change','Process Change Request','Deviation Request','Trial Request')),
  customer_id    uuid references customers(id) on delete set null,
  part_id        uuid references parts(id)     on delete set null,
  part_number    text,                       -- snapshot, so history survives part edits
  part_name      text,
  description    text,
  reason         text,
  target_date    date,
  status         text not null default 'Pending'
                 check (status in ('Pending','For Approval','Returned','Approved','Rejected','Completed')),
  current_level  int  not null default 0,    -- 0 = not submitted, 1..3 = awaiting that level
  requestor_id   uuid not null references users(id),
  submitted_at   timestamptz,
  closed_at      timestamptz,                -- set when finally Approved/Rejected
  last_reminder_on date,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
drop trigger if exists trg_request_no on requests;
create trigger trg_request_no before insert on requests
  for each row execute function set_request_no();
create index if not exists idx_requests_status    on requests(status);
create index if not exists idx_requests_customer  on requests(customer_id);
create index if not exists idx_requests_requestor on requests(requestor_id);
create index if not exists idx_requests_target    on requests(target_date);

-- ---------- APPROVAL STEPS (the route: L1 Engineer, L2 Supervisor, L3 QA Manager) ----------
create table if not exists request_steps (
  id           uuid primary key default gen_random_uuid(),
  request_id   uuid not null references requests(id) on delete cascade,
  level        int  not null check (level between 1 and 3),
  role         text not null check (role in ('engineer','supervisor','qa_manager')),
  approver_id  uuid references users(id),    -- optional: named approver; null = any user of the role
  status       text not null default 'Waiting' check (status in ('Waiting','Pending','Approved','Rejected','Returned')),
  acted_by     uuid references users(id),
  acted_at     timestamptz,
  comment      text,
  unique (request_id, level)
);
create index if not exists idx_steps_request  on request_steps(request_id);
create index if not exists idx_steps_approver on request_steps(approver_id);

-- ---------- ELECTRONIC APPROVAL HISTORY (append-only) ----------
create table if not exists approval_history (
  id          uuid primary key default gen_random_uuid(),
  request_id  uuid not null references requests(id) on delete cascade,
  level       int,
  action      text not null check (action in ('Submitted','Approved','Rejected','Returned','Resubmitted','Completed','Comment')),
  user_id     uuid references users(id),
  user_name   text,
  user_role   text,
  comment     text,
  created_at  timestamptz not null default now()
);
create index if not exists idx_history_request on approval_history(request_id);

-- ---------- REQUEST ATTACHMENTS ----------
create table if not exists request_attachments (
  id           uuid primary key default gen_random_uuid(),
  request_id   uuid not null references requests(id) on delete cascade,
  file_name    text not null,
  storage_path text not null,
  mime_type    text,
  size_bytes   bigint,
  uploaded_by  uuid references users(id),
  created_at   timestamptz not null default now()
);

-- ---------- DOCUMENT REPOSITORY ----------
create table if not exists documents (
  id             uuid primary key default gen_random_uuid(),
  doc_number     text,
  title          text not null,
  category       text not null check (category in (
                   'PPAP Documents','Packaging Standards','Inspection Reports',
                   'Customer Drawings','Control Plans','QCPC','Other')),
  customer_id    uuid references customers(id) on delete set null,
  part_id        uuid references parts(id)     on delete set null,
  current_version int not null default 1,
  created_by     uuid references users(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_documents_category on documents(category);

create table if not exists document_versions (
  id            uuid primary key default gen_random_uuid(),
  document_id   uuid not null references documents(id) on delete cascade,
  version_no    int  not null,
  file_name     text not null,
  storage_path  text not null,
  mime_type     text,
  size_bytes    bigint,
  change_note   text,
  uploaded_by   uuid references users(id),
  created_at    timestamptz not null default now(),
  unique (document_id, version_no)
);

-- ---------- IN-APP NOTIFICATIONS (bell) ----------
create table if not exists notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references users(id) on delete cascade,
  request_id  uuid references requests(id) on delete cascade,
  title       text not null,
  message     text,
  is_read     boolean not null default false,
  created_at  timestamptz not null default now()
);
create index if not exists idx_notif_user on notifications(user_id, is_read);

-- ---------- EMAIL LOG ----------
create table if not exists email_log (
  id          uuid primary key default gen_random_uuid(),
  to_email    text not null,
  subject     text not null,
  event       text,
  request_id  uuid references requests(id) on delete set null,
  status      text not null,           -- sent | failed | skipped
  error       text,
  created_at  timestamptz not null default now()
);

-- ---------- AUDIT TRAIL ----------
create table if not exists audit_logs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references users(id) on delete set null,
  user_name   text,
  action      text not null,           -- CREATE | UPDATE | DELETE | LOGIN | APPROVE ...
  entity      text not null,           -- request | customer | part | user | document ...
  entity_id   text,
  old_value   jsonb,
  new_value   jsonb,
  ip_address  text,
  created_at  timestamptz not null default now()
);
create index if not exists idx_audit_entity  on audit_logs(entity, entity_id);
create index if not exists idx_audit_created on audit_logs(created_at desc);

-- ---------- updated_at maintenance ----------
create or replace function touch_updated_at() returns trigger as $$
begin new.updated_at := now(); return new; end $$ language plpgsql;

do $$
declare t text;
begin
  foreach t in array array['users','customers','parts','requests','documents'] loop
    execute format('drop trigger if exists trg_touch_%1$s on %1$s', t);
    execute format('create trigger trg_touch_%1$s before update on %1$s for each row execute function touch_updated_at()', t);
  end loop;
end $$;

-- ---------- SECURITY ----------
-- The Node API uses the service-role key (bypasses RLS). Enabling RLS with no
-- policies blocks every access made with the public anon key.
alter table users               enable row level security;
alter table customers           enable row level security;
alter table parts               enable row level security;
alter table requests            enable row level security;
alter table request_steps       enable row level security;
alter table approval_history    enable row level security;
alter table request_attachments enable row level security;
alter table documents           enable row level security;
alter table document_versions   enable row level security;
alter table notifications       enable row level security;
alter table email_log           enable row level security;
alter table audit_logs          enable row level security;

-- ---------- SEED DATA ----------
insert into customers (name, contact_person, email, remarks) values
  ('DAIHO',        null, null, 'Seed data'),
  ('YAMAHA',       null, null, 'Seed data'),
  ('FTECH',        null, null, 'Seed data'),
  ('MITSUBA',      null, null, 'Seed data'),
  ('NIDEC',        null, null, 'Seed data'),
  ('SANYO DENKI',  null, null, 'Seed data'),
  ('SUMITRONICS',  null, null, 'Seed data')
on conflict (name) do nothing;

-- Storage bucket for attachments and documents (private)
insert into storage.buckets (id, name, public)
values ('qams-files', 'qams-files', false)
on conflict (id) do nothing;
