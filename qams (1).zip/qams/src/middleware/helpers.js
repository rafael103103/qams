// Small helpers shared by routes.

/** Wrap async route handlers so rejected promises reach the error middleware. */
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** Throw an HTTP error from anywhere in a handler. */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

/** Throws a 500 if a Supabase call returned an error. */
function check({ data, error }) {
  if (error) { console.error('[db]', error); throw new HttpError(500, error.message); }
  return data;
}

/** Keep only whitelisted keys (prevents mass-assignment) and convert '' to null. */
function pick(obj, keys) {
  const out = {};
  for (const k of keys) if (obj[k] !== undefined) out[k] = obj[k] === '' ? null : obj[k];
  return out;
}

function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  const status = err.status || (err.code === 'LIMIT_FILE_SIZE' ? 413 : 500);
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 && process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message });
}

module.exports = { wrap, HttpError, check, pick, errorHandler };
