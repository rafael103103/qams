// Authentication (JWT) and role-based access control middleware.
const jwt = require('jsonwebtoken');
const { supabase } = require('../config/supabase');

const ROLES = ['requestor', 'engineer', 'supervisor', 'qa_manager', 'admin'];

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  });
}

/** Verifies the Bearer token and loads a fresh user record (so deactivation takes effect immediately). */
async function authenticate(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Authentication required' });

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const { data: user, error } = await supabase
      .from('users')
      .select('id, full_name, email, role, department, is_active')
      .eq('id', payload.sub)
      .single();
    if (error || !user || !user.is_active) return res.status(401).json({ error: 'Account not found or disabled' });

    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }
}

/** Usage: router.post('/', requireRole('admin','qa_manager'), handler) */
function requireRole(...allowed) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Authentication required' });
    if (req.user.role === 'admin' || allowed.includes(req.user.role)) return next();
    return res.status(403).json({ error: 'You do not have permission to do this' });
  };
}

module.exports = { ROLES, signToken, authenticate, requireRole };
