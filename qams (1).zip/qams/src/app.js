// Express application (used locally via server.js and on Vercel via api/index.js).
require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { errorHandler } = require('./middleware/helpers');
const { authenticate } = require('./middleware/auth');

const app = express();
app.set('trust proxy', 1); // Vercel / reverse proxies

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'script-src': ["'self'", 'https://cdn.jsdelivr.net'],
      'style-src': ["'self'", "'unsafe-inline'", 'https://cdn.jsdelivr.net'],
      'font-src': ["'self'", 'https://cdn.jsdelivr.net', 'data:'],
      'img-src': ["'self'", 'data:'],
      'connect-src': ["'self'"],
    },
  },
}));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true }));
app.use(express.json({ limit: '1mb' }));

// Brute-force protection on login; general limiter on the API
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many login attempts. Try again later.' } }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// Public: auth (login) and cron (protected by CRON_SECRET)
app.use('/api/auth', require('./routes/auth'));
app.use('/api/cron', require('./routes/cron'));

// Everything below requires a valid session
app.use('/api', authenticate);
app.use('/api/users', require('./routes/users'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/parts', require('./routes/parts'));
app.use('/api/requests', require('./routes/requests'));
app.use('/api/documents', require('./routes/documents'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/audit', require('./routes/audit'));
app.use('/api/notifications', require('./routes/notifications'));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

// Static frontend (local dev / single-host deploy). On Vercel, /public is served by the CDN.
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use(errorHandler);
module.exports = app;
