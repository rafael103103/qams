// Email notification service (SMTP via nodemailer) + in-app notifications.
const nodemailer = require('nodemailer');
const { supabase } = require('../config/supabase');

let transporter;
function getTransport() {
  if (transporter !== undefined) return transporter;
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER) { transporter = null; return null; }
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE) === 'true',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  return transporter;
}

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/** Branded HTML email shell. */
function template({ heading, intro, rows = [], buttonText, link, note }) {
  const tr = rows.map(([k, v]) =>
    `<tr><td style="padding:6px 12px;color:#667;width:140px">${esc(k)}</td><td style="padding:6px 12px"><b>${esc(v)}</b></td></tr>`).join('');
  return `<!doctype html><html><body style="margin:0;background:#F5F7FA;font-family:Segoe UI,Arial,sans-serif">
  <div style="max-width:600px;margin:24px auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #e3e8ef">
    <div style="background:#0F4C81;color:#fff;padding:18px 24px;font-size:18px">QAMS &middot; Approval Management</div>
    <div style="padding:24px;color:#222">
      <h2 style="margin:0 0 8px;color:#0F4C81">${esc(heading)}</h2>
      <p style="line-height:1.5">${esc(intro)}</p>
      <table style="border-collapse:collapse;background:#F5F7FA;border-radius:6px;width:100%">${tr}</table>
      ${note ? `<p style="background:#fff8e1;padding:10px 12px;border-left:4px solid #1ABC9C">${esc(note)}</p>` : ''}
      ${link ? `<p style="text-align:center;margin:24px 0"><a href="${link}" style="background:#1ABC9C;color:#fff;text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:600">${esc(buttonText || 'Open request')}</a></p>` : ''}
    </div>
    <div style="padding:12px 24px;font-size:12px;color:#889;background:#fafbfc">This is an automated message from QAMS. Please do not reply.</div>
  </div></body></html>`;
}

/** Send one email and record the result in email_log. Never throws. */
async function sendMail({ to, subject, html, event, requestId }) {
  if (!to) return;
  const t = getTransport();
  let status = 'sent', error = null;
  try {
    if (!t) { status = 'skipped'; error = 'SMTP not configured'; console.log(`[mail:skipped] ${to} :: ${subject}`); }
    else await t.sendMail({ from: process.env.MAIL_FROM || process.env.SMTP_USER, to, subject, html });
  } catch (e) { status = 'failed'; error = e.message; console.error('[mail]', e.message); }
  await supabase.from('email_log').insert({ to_email: to, subject, event, request_id: requestId || null, status, error });
}

/** Email + bell notification to a list of users. */
async function notifyUsers(users, { event, request, title, message, html }) {
  const list = (users || []).filter(Boolean);
  if (!list.length) return;
  await supabase.from('notifications').insert(
    list.map((u) => ({ user_id: u.id, request_id: request?.id || null, title, message })));
  await Promise.allSettled(list.map((u) =>
    sendMail({ to: u.email, subject: `[QAMS] ${title}`, html, event, requestId: request?.id })));
}

const linkTo = (id) => `${process.env.APP_URL || ''}/app.html#/requests/${id}`;

module.exports = { sendMail, notifyUsers, template, linkTo };
