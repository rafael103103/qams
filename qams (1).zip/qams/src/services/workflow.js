// Sequential approval workflow engine.
//   Level 1 Engineer -> Level 2 Section Head/Supervisor -> Level 3 QA Manager
// Status lifecycle:
//   Pending -> (submit) For Approval -> Approved -> Completed
//                          |-> Rejected   (terminal)
//                          |-> Returned -> (edit + resubmit) For Approval
const { supabase } = require('../config/supabase');
const { check, HttpError } = require('../middleware/helpers');
const { notifyUsers, template, linkTo } = require('./mailer');

const ROUTE = [
  { level: 1, role: 'engineer',   label: 'Engineer' },
  { level: 2, role: 'supervisor', label: 'Section Head / Supervisor' },
  { level: 3, role: 'qa_manager', label: 'QA Manager' },
];
const ROLE_LABEL = { requestor: 'Requestor', engineer: 'Engineer', supervisor: 'Supervisor', qa_manager: 'QA Manager', admin: 'Administrator' };

const USER_COLS = 'id, full_name, email, role';

/** Create the 3 approval steps for a request (optionally with named approvers). */
async function createSteps(requestId, approvers = {}) {
  const rows = ROUTE.map((r) => ({
    request_id: requestId, level: r.level, role: r.role,
    approver_id: approvers[r.role] || null, status: 'Waiting',
  }));
  check(await supabase.from('request_steps').insert(rows));
}

async function loadRequest(id) {
  const { data } = await supabase.from('requests')
    .select('*, customer:customers(name), requestor:users!requests_requestor_id_fkey(id, full_name, email)')
    .eq('id', id).single();
  if (!data) throw new HttpError(404, 'Request not found');
  return data;
}

async function loadSteps(requestId) {
  return check(await supabase.from('request_steps').select('*').eq('request_id', requestId).order('level'));
}

/** Users who may act on a step: the named approver, otherwise everyone active with that role. */
async function stepApprovers(step) {
  if (step.approver_id) {
    const { data } = await supabase.from('users').select(USER_COLS).eq('id', step.approver_id).eq('is_active', true);
    return data || [];
  }
  const { data } = await supabase.from('users').select(USER_COLS).eq('role', step.role).eq('is_active', true);
  return data || [];
}

function canAct(user, step) {
  if (user.role === 'admin') return true;
  if (step.approver_id) return step.approver_id === user.id;
  return step.role === user.role;
}

const rowsFor = (r) => [
  ['Request No.', r.request_no], ['Type', r.type], ['Customer', r.customer?.name || '-'],
  ['Part', `${r.part_number || '-'} ${r.part_name || ''}`.trim()], ['Target date', r.target_date || '-'],
];

async function history(request, user, action, level, comment) {
  check(await supabase.from('approval_history').insert({
    request_id: request.id, level, action, user_id: user.id, user_name: user.full_name,
    user_role: ROLE_LABEL[user.role], comment: comment || null,
  }));
}

/** Notify the approvers of `step` that a request is waiting for them. */
async function askApprovers(request, step) {
  const users = await stepApprovers(step);
  const label = ROUTE[step.level - 1].label;
  await notifyUsers(users, {
    event: 'approval_needed', request,
    title: `Approval needed: ${request.request_no}`,
    message: `${request.type} - ${request.part_number || ''} awaits your approval (Level ${step.level}: ${label}).`,
    html: template({
      heading: 'Your approval is required',
      intro: `A request has been submitted and is waiting for your decision as ${label} (Level ${step.level} of 3).`,
      rows: [...rowsFor(request), ['Requested by', request.requestor.full_name]],
      buttonText: 'Review request', link: linkTo(request.id),
    }),
  });
}

/** Requestor submits (or resubmits after a return). Restarts the route at Level 1. */
async function submit(request, user) {
  if (!['Pending', 'Returned'].includes(request.status)) throw new HttpError(409, `A request in status "${request.status}" cannot be submitted`);
  if (request.requestor_id !== user.id && user.role !== 'admin') throw new HttpError(403, 'Only the requestor can submit this request');

  const resubmit = request.status === 'Returned';
  let steps = await loadSteps(request.id);
  if (!steps.length) { await createSteps(request.id); steps = await loadSteps(request.id); }

  // reset route
  check(await supabase.from('request_steps')
    .update({ status: 'Waiting', acted_by: null, acted_at: null, comment: null }).eq('request_id', request.id));
  check(await supabase.from('request_steps').update({ status: 'Pending' }).eq('request_id', request.id).eq('level', 1));

  check(await supabase.from('requests').update({
    status: 'For Approval', current_level: 1, closed_at: null,
    submitted_at: request.submitted_at || new Date().toISOString(),
  }).eq('id', request.id));

  await history(request, user, resubmit ? 'Resubmitted' : 'Submitted', 0, null);

  // Email 1: confirmation to requestor ("Request Created")
  await notifyUsers([request.requestor], {
    event: 'request_created', request,
    title: `Request ${request.request_no} submitted`,
    message: 'Your request was submitted and routed to the Engineer for approval.',
    html: template({ heading: 'Request submitted', intro: 'Your request has been created and sent to Level 1 (Engineer).', rows: rowsFor(request), buttonText: 'Track request', link: linkTo(request.id) }),
  });
  // Email 2: first approver
  await askApprovers(request, steps[0]);
}

/**
 * Approve / Reject / Return for the request's current level.
 * Uses a conditional update so two people can't act on the same level twice.
 */
async function act(request, user, action, comment) {
  if (!['approve', 'reject', 'return'].includes(action)) throw new HttpError(400, 'Invalid action');
  if (request.status !== 'For Approval') throw new HttpError(409, 'This request is not awaiting approval');
  if (['reject', 'return'].includes(action) && !(comment || '').trim()) throw new HttpError(400, 'A comment is required to reject or return a request');

  const steps = await loadSteps(request.id);
  const step = steps.find((s) => s.level === request.current_level);
  if (!step || step.status !== 'Pending') throw new HttpError(409, 'No pending approval step');
  if (!canAct(user, step)) throw new HttpError(403, 'You are not the approver for this level');
  if (request.requestor_id === user.id) throw new HttpError(403, 'You cannot approve your own request (segregation of duties)');

  const now = new Date().toISOString();
  const stepStatus = { approve: 'Approved', reject: 'Rejected', return: 'Returned' }[action];

  // Guard: claim the step atomically
  const { data: claimed } = await supabase.from('request_steps')
    .update({ status: stepStatus, acted_by: user.id, acted_at: now, comment: comment || null })
    .eq('id', step.id).eq('status', 'Pending').select('id');
  if (!claimed?.length) throw new HttpError(409, 'This step was already actioned by someone else');

  const histAction = { approve: 'Approved', reject: 'Rejected', return: 'Returned' }[action];
  await history(request, user, histAction, step.level, comment);

  if (action === 'approve') {
    if (step.level < 3) {
      const next = steps.find((s) => s.level === step.level + 1);
      check(await supabase.from('request_steps').update({ status: 'Pending' }).eq('id', next.id));
      check(await supabase.from('requests').update({ current_level: next.level }).eq('id', request.id));
      await askApprovers(request, next); // auto-email next approver
      await notifyUsers([request.requestor], {
        event: 'request_approved', request,
        title: `${request.request_no} approved at Level ${step.level}`,
        message: `${user.full_name} approved. Now with ${ROUTE[next.level - 1].label}.`,
        html: template({ heading: `Approved at Level ${step.level}`, intro: `${user.full_name} (${ROLE_LABEL[user.role]}) approved your request. It has moved to ${ROUTE[next.level - 1].label}.`, rows: rowsFor(request), note: comment ? `Comment: ${comment}` : null, link: linkTo(request.id) }),
      });
    } else { // final approval closes the request
      check(await supabase.from('requests').update({ status: 'Approved', current_level: 3, closed_at: now }).eq('id', request.id));
      const approvedBy = (await supabase.from('users').select(USER_COLS).in('id', steps.map((s) => s.acted_by).filter(Boolean))).data || [];
      await notifyUsers([request.requestor, ...approvedBy.filter((u) => u.id !== request.requestor.id)], {
        event: 'request_approved', request,
        title: `${request.request_no} fully approved`,
        message: 'All three approval levels are complete. The request is closed as Approved.',
        html: template({ heading: 'Request fully approved', intro: 'All approval levels are complete and the request is now closed.', rows: rowsFor(request), note: comment ? `Final comment: ${comment}` : null, link: linkTo(request.id) }),
      });
    }
  } else if (action === 'reject') {
    check(await supabase.from('requests').update({ status: 'Rejected', closed_at: now }).eq('id', request.id));
    await notifyUsers([request.requestor], {
      event: 'request_rejected', request,
      title: `${request.request_no} rejected`,
      message: `Rejected by ${user.full_name}: ${comment}`,
      html: template({ heading: 'Request rejected', intro: `${user.full_name} (${ROLE_LABEL[user.role]}) rejected your request at Level ${step.level}.`, rows: rowsFor(request), note: `Reason: ${comment}`, link: linkTo(request.id) }),
    });
  } else { // return for revision
    check(await supabase.from('requests').update({ status: 'Returned', current_level: 0 }).eq('id', request.id));
    await notifyUsers([request.requestor], {
      event: 'request_returned', request,
      title: `${request.request_no} returned for revision`,
      message: `Returned by ${user.full_name}: ${comment}`,
      html: template({ heading: 'Returned for revision', intro: `${user.full_name} (${ROLE_LABEL[user.role]}) returned your request. Please update it and resubmit.`, rows: rowsFor(request), note: `Comment: ${comment}`, link: linkTo(request.id) }),
    });
  }
  return { level: step.level, action };
}

/** Requestor (or admin) marks an Approved request as Completed. */
async function complete(request, user, comment) {
  if (request.status !== 'Approved') throw new HttpError(409, 'Only approved requests can be completed');
  if (request.requestor_id !== user.id && user.role !== 'admin') throw new HttpError(403, 'Only the requestor can complete this request');
  check(await supabase.from('requests').update({ status: 'Completed' }).eq('id', request.id));
  await history(request, user, 'Completed', 3, comment);
}

module.exports = { ROUTE, ROLE_LABEL, createSteps, loadRequest, loadSteps, stepApprovers, canAct, submit, act, complete };
