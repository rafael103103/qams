// Audit trail: who did what, when, with old and new values.
const { supabase } = require('../config/supabase');

const SENSITIVE = ['password_hash', 'password'];
const clean = (o) => {
  if (!o) return null;
  const c = { ...o };
  SENSITIVE.forEach((k) => delete c[k]);
  return c;
};

/** Only the fields that actually changed (keeps the log readable). */
function diff(oldObj = {}, newObj = {}) {
  const o = {}, n = {};
  for (const k of Object.keys(newObj)) {
    if (JSON.stringify(oldObj[k]) !== JSON.stringify(newObj[k])) { o[k] = oldObj[k] ?? null; n[k] = newObj[k]; }
  }
  return { old: o, new: n };
}

async function audit(req, { action, entity, entityId, oldValue, newValue }) {
  try {
    await supabase.from('audit_logs').insert({
      user_id: req.user?.id || null,
      user_name: req.user?.full_name || null,
      action, entity,
      entity_id: entityId ? String(entityId) : null,
      old_value: clean(oldValue),
      new_value: clean(newValue),
      ip_address: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    });
  } catch (e) { console.error('[audit] failed', e.message); } // never block the business action
}

module.exports = { audit, diff };
