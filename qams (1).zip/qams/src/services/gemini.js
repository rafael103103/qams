// Google Gemini integration (REST API, free tier). Prompts live here so they are easy to tune.
const MODEL = () => process.env.GEMINI_MODEL || 'gemini-2.0-flash';

const SYSTEM = `You are a senior quality-engineering and business-writing assistant for a manufacturing company that supplies automotive/motor parts to Japanese customers (PPAP, APQP, QCPC, 4M change, CAPA).
Write clear, professional, concise English. Never invent facts, numbers or dates that were not supplied: use [placeholders] instead. Return plain text without markdown symbols such as ** or #, unless a table is requested.`;

/** Low-level call. `parts` is an array of Gemini content parts (text or inlineData). */
async function generate(parts, { temperature = 0.4 } = {}) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) { const e = new Error('GEMINI_API_KEY is not configured'); e.status = 503; throw e; }

  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL()}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM }] },
      contents: [{ role: 'user', parts }],
      generationConfig: { temperature, maxOutputTokens: 2048 },
    }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const e = new Error(res.status === 429 ? 'AI free-tier limit reached. Please wait a minute and try again.' : (json.error?.message || 'Gemini request failed'));
    e.status = res.status === 429 ? 429 : 502; throw e;
  }
  const text = json.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') || '';
  if (!text) { const e = new Error('The AI returned no content (it may have been blocked). Try rephrasing your input.'); e.status = 502; throw e; }
  return text.trim();
}

const EMAIL_KINDS = {
  sample_submission: 'Sample Submission to a customer',
  follow_up: 'Follow-up on a pending request',
  ppap: 'PPAP Submission',
  packaging: 'Packaging Approval request',
  customer: 'General customer communication',
};

// Each tool builds a prompt from the validated input.
const tools = {
  email: ({ kind, tone, details, recipient }) =>
    `Write a professional email. Type: ${EMAIL_KINDS[kind] || EMAIL_KINDS.customer}. Tone: ${tone || 'polite and formal'}.
Recipient: ${recipient || '[Recipient name]'}.
Key details/context:\n${details}\n
Format: first line "Subject: ...", blank line, greeting, short body paragraphs, closing, signature placeholder [Your Name], [Position], [Company].`,

  grammar: ({ text }) =>
    `Correct the grammar, spelling, punctuation and sentence structure of the text below. Keep the original meaning and tone.
Output the corrected text first, then a blank line, then "Changes made:" followed by a short list of the main corrections.\n\nTEXT:\n${text}`,

  rephrase: ({ text, tone }) =>
    `Rewrite the casual text below into ${tone || 'professional business'} language suitable for a manufacturing/quality context. Keep all facts. Provide the rewritten text only.\n\nTEXT:\n${text}`,

  capa: ({ problem, partNumber, customer, rootCause }) =>
    `Generate a CAPA (8D style) for this quality issue. Use these headings exactly:
Problem Statement, Containment Action, Root Cause (use the supplied cause or propose likely causes using 5-Why / 4M), Corrective Action, Preventive Action, Verification of Effectiveness.
Under Containment, Corrective and Preventive actions, give numbered, specific, actionable items, each with a suggested [Owner] and [Target date] placeholder.
Customer: ${customer || '-'} | Part number: ${partNumber || '-'}
Issue description:\n${problem}\nKnown root cause: ${rootCause || 'not yet determined'}`,

  minutes: ({ notes, title, date, attendees }) =>
    `Turn these raw meeting notes into formal meeting minutes.
Meeting: ${title || '[Title]'} | Date: ${date || '[Date]'} | Attendees: ${attendees || '[Attendees]'}
Sections: Summary (3-5 sentences), Key Decisions, then "Action Items" as a table with columns: No. | Action | Responsible | Deadline. Use [TBD] when responsible person or deadline is not stated.\n\nNOTES:\n${notes}`,

  inspection: ({ text, instructions }) =>
    `Summarize the inspection results provided. Sections: Overview, Key Measurements / Findings, Out-of-Spec or Nonconforming Items (with values vs specification if given), Overall Judgement (OK / NG / Needs review), Recommended Next Steps.
${instructions ? 'Extra instructions: ' + instructions + '\n' : ''}${text ? '\nINSPECTION DATA:\n' + text : '\nThe inspection report is attached.'}`,
};

module.exports = { generate, tools };
