// Reports: JSON preview, Excel and PDF export.
const router = require('express').Router();
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { supabase } = require('../config/supabase');
const { requireRole } = require('../middleware/auth');
const { wrap, HttpError, check } = require('../middleware/helpers');

router.use(requireRole('engineer', 'supervisor', 'qa_manager'));

const d = (v) => (v ? String(v).slice(0, 10) : '');
const days = (a, b) => (a && b ? +((new Date(b) - new Date(a)) / 86400000).toFixed(1) : null);

async function fetchRequests({ from, to, customer_id }) {
  let q = supabase.from('requests').select('*, customer:customers(name), requestor:users!requests_requestor_id_fkey(full_name)').order('request_date', { ascending: false });
  if (from) q = q.gte('request_date', from);
  if (to) q = q.lte('request_date', to);
  if (customer_id) q = q.eq('customer_id', customer_id);
  return check(await q);
}

// Each builder returns { title, columns: [{header, key, width}], rows: [...] }
const builders = {
  async status(p) {
    const rows = await fetchRequests(p);
    const today = new Date().toISOString().slice(0, 10);
    return {
      title: 'Request Status Report',
      columns: [
        { header: 'Request No.', key: 'no', width: 16 }, { header: 'Date', key: 'date', width: 12 }, { header: 'Type', key: 'type', width: 24 },
        { header: 'Customer', key: 'customer', width: 16 }, { header: 'Part No.', key: 'part', width: 18 }, { header: 'Requestor', key: 'by', width: 18 },
        { header: 'Target', key: 'target', width: 12 }, { header: 'Status', key: 'status', width: 14 }, { header: 'Level', key: 'level', width: 7 }, { header: 'Overdue', key: 'overdue', width: 9 },
      ],
      rows: rows.map((r) => ({
        no: r.request_no, date: d(r.request_date), type: r.type, customer: r.customer?.name || '', part: r.part_number || '', by: r.requestor?.full_name || '',
        target: d(r.target_date), status: r.status, level: r.current_level || '',
        overdue: ['Pending', 'For Approval', 'Returned'].includes(r.status) && r.target_date && r.target_date < today ? 'YES' : '',
      })),
    };
  },
  async leadtime(p) {
    const rows = (await fetchRequests(p)).filter((r) => r.submitted_at && r.closed_at);
    return {
      title: 'Approval Lead Time Report',
      columns: [
        { header: 'Request No.', key: 'no', width: 16 }, { header: 'Type', key: 'type', width: 24 }, { header: 'Customer', key: 'customer', width: 16 },
        { header: 'Submitted', key: 'sub', width: 12 }, { header: 'Closed', key: 'closed', width: 12 }, { header: 'Result', key: 'status', width: 12 }, { header: 'Lead time (days)', key: 'days', width: 16 },
      ],
      rows: rows.map((r) => ({ no: r.request_no, type: r.type, customer: r.customer?.name || '', sub: d(r.submitted_at), closed: d(r.closed_at), status: r.status, days: days(r.submitted_at, r.closed_at) })),
    };
  },
  async customer(p) {
    const rows = await fetchRequests(p);
    const m = {};
    for (const r of rows) {
      const n = r.customer?.name || 'Unassigned';
      m[n] = m[n] || { customer: n, total: 0, approved: 0, rejected: 0, open: 0, lt: [] };
      const c = m[n]; c.total++;
      if (['Approved', 'Completed'].includes(r.status)) { c.approved++; const x = days(r.submitted_at, r.closed_at); if (x !== null) c.lt.push(x); }
      else if (r.status === 'Rejected') c.rejected++; else c.open++;
    }
    return {
      title: 'Customer Report',
      columns: [{ header: 'Customer', key: 'customer', width: 22 }, { header: 'Total', key: 'total', width: 9 }, { header: 'Approved', key: 'approved', width: 10 }, { header: 'Rejected', key: 'rejected', width: 10 }, { header: 'Open', key: 'open', width: 9 }, { header: 'Avg lead time (days)', key: 'avg', width: 20 }],
      rows: Object.values(m).sort((a, b) => b.total - a.total).map((c) => ({ ...c, avg: c.lt.length ? +(c.lt.reduce((a, b) => a + b, 0) / c.lt.length).toFixed(1) : '' })),
    };
  },
  async monthly(p) {
    const rows = await fetchRequests(p);
    const m = {};
    for (const r of rows) {
      const k = (r.submitted_at || r.created_at).slice(0, 7);
      m[k] = m[k] || { month: k, created: 0, approved: 0, rejected: 0, returned: 0 };
      m[k].created++;
      if (['Approved', 'Completed'].includes(r.status)) m[k].approved++;
      if (r.status === 'Rejected') m[k].rejected++;
      if (r.status === 'Returned') m[k].returned++;
    }
    return {
      title: 'Monthly Activity Report',
      columns: [{ header: 'Month', key: 'month', width: 12 }, { header: 'Submitted', key: 'created', width: 12 }, { header: 'Approved', key: 'approved', width: 12 }, { header: 'Rejected', key: 'rejected', width: 12 }, { header: 'Returned', key: 'returned', width: 12 }],
      rows: Object.values(m).sort((a, b) => b.month.localeCompare(a.month)),
    };
  },
};

async function toExcel(rep, res) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet(rep.title.slice(0, 30));
  ws.columns = rep.columns;
  ws.addRows(rep.rows);
  const head = ws.getRow(1);
  head.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  head.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F4C81' } };
  ws.views = [{ state: 'frozen', ySplit: 1 }];
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: rep.columns.length } };
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${rep.title.replace(/\s+/g, '_')}.xlsx"`);
  await wb.xlsx.write(res);
  res.end();
}

function toPdf(rep, res) {
  const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 36 });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${rep.title.replace(/\s+/g, '_')}.pdf"`);
  doc.pipe(res);
  doc.fontSize(18).fillColor('#0F4C81').text(rep.title);
  doc.fontSize(9).fillColor('#666').text(`Generated ${new Date().toISOString().slice(0, 16).replace('T', ' ')} UTC  |  ${rep.rows.length} rows`).moveDown(0.8);

  const totalW = rep.columns.reduce((s, c) => s + c.width, 0);
  const scale = (doc.page.width - 72) / totalW;
  const widths = rep.columns.map((c) => c.width * scale);
  const drawRow = (vals, header) => {
    const y = doc.y;
    if (y > doc.page.height - 60) { doc.addPage(); return drawRow(vals, header); }
    if (header) doc.rect(36, y - 2, doc.page.width - 72, 16).fill('#0F4C81');
    let x = 36;
    doc.fontSize(8).fillColor(header ? '#fff' : '#222');
    vals.forEach((v, i) => { doc.text(String(v ?? ''), x + 2, y + 1, { width: widths[i] - 4, height: 12, ellipsis: true, lineBreak: false }); x += widths[i]; });
    doc.y = y + 16;
    if (!header) doc.moveTo(36, doc.y - 2).lineTo(doc.page.width - 36, doc.y - 2).strokeColor('#e3e8ef').stroke();
  };
  drawRow(rep.columns.map((c) => c.header), true);
  rep.rows.forEach((r) => drawRow(rep.columns.map((c) => r[c.key]), false));
  doc.end();
}

// GET /api/reports/:type?format=json|xlsx|pdf&from=&to=&customer_id=
router.get('/:type', wrap(async (req, res) => {
  const build = builders[req.params.type];
  if (!build) throw new HttpError(404, 'Unknown report');
  const rep = await build({ from: req.query.from, to: req.query.to, customer_id: req.query.customer_id });
  const fmt = req.query.format || 'json';
  if (fmt === 'xlsx') return toExcel(rep, res);
  if (fmt === 'pdf') return toPdf(rep, res);
  res.json(rep);
}));

module.exports = router;
