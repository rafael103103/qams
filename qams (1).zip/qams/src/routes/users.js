// User administration (admin only), plus a lightweight approver directory for all users.
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { supabase } = require('../config/supabase');
const { requireRole, ROLES } = require('../middleware/auth');
const { wrap, HttpError, check, pick } = require('../middleware/helpers');
const { audit, diff } = require('../services/audit');

const COLS = 'id, full_name, email, role, department, is_active, created_at';

// Directory used by the request form to pick named approvers
router.get('/directory', wrap(async (req, res) => {
  const data = check(await supabase.from('users').select('id, full_name, role').eq('is_active', true)
    .in('role', ['engineer', 'supervisor', 'qa_manager']).order('full_name'));
  res.json(data);
}));

router.use(requireRole('admin'));

router.get('/', wrap(async (req, res) => {
  res.json(check(await supabase.from('users').select(COLS).order('full_name')));
}));

router.post('/', wrap(async (req, res) => {
  const b = req.body;
  if (!b.full_name || !b.email || !b.password) throw new HttpError(400, 'Name, email and password are required');
  if (b.password.length < 8) throw new HttpError(400, 'Password must be at least 8 characters');
  if (!ROLES.includes(b.role)) throw new HttpError(400, 'Invalid role');
  const row = { ...pick(b, ['full_name', 'role', 'department']), email: b.email.trim().toLowerCase(), password_hash: await bcrypt.hash(b.password, 12) };
  const { data, error } = await supabase.from('users').insert(row).select(COLS).single();
  if (error) throw new HttpError(error.code === '23505' ? 409 : 500, error.code === '23505' ? 'Email already exists' : error.message);
  await audit(req, { action: 'CREATE', entity: 'user', entityId: data.id, newValue: data });
  res.status(201).json(data);
}));

router.put('/:id', wrap(async (req, res) => {
  const { data: old } = await supabase.from('users').select(COLS).eq('id', req.params.id).single();
  if (!old) throw new HttpError(404, 'User not found');
  const upd = pick(req.body, ['full_name', 'role', 'department', 'is_active']);
  if (upd.role && !ROLES.includes(upd.role)) throw new HttpError(400, 'Invalid role');
  if (req.params.id === req.user.id && (upd.is_active === false || (upd.role && upd.role !== 'admin')))
    throw new HttpError(400, 'You cannot disable or demote your own account');
  if (req.body.password) {
    if (req.body.password.length < 8) throw new HttpError(400, 'Password must be at least 8 characters');
    upd.password_hash = await bcrypt.hash(req.body.password, 12);
  }
  const data = check(await supabase.from('users').update(upd).eq('id', req.params.id).select(COLS).single());
  const d = diff(old, data);
  if (req.body.password) d.new.password = '(changed)';
  await audit(req, { action: 'UPDATE', entity: 'user', entityId: data.id, oldValue: d.old, newValue: d.new });
  res.json(data);
}));

module.exports = router;
