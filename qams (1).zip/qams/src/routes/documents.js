// Document repository with version history and search.
const router = require('express').Router();
const multer = require('multer');
const { supabase, BUCKET } = require('../config/supabase');
const { requireRole } = require('../middleware/auth');
const { wrap, HttpError, check } = require('../middleware/helpers');
const { audit } = require('../services/audit');

const CATEGORIES = ['PPAP Documents', 'Packaging Standards', 'Inspection Reports', 'Customer Drawings', 'Control Plans', 'QCPC', 'Other'];
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024 } });
const SELECT = '*, customer:customers(name), part:parts(part_number), creator:users!documents_created_by_fkey(full_name)';
const canWrite = requireRole('requestor', 'engineer', 'supervisor', 'qa_manager');

async function storeFile(docId, versionNo, file) {
  const safe = file.originalname.replace(/[^\w.\-]+/g, '_');
  const path = `documents/${docId}/v${versionNo}_${safe}`;
  const up = await supabase.storage.from(BUCKET).upload(path, file.buffer, { contentType: file.mimetype });
  if (up.error) throw new HttpError(500, up.error.message);
  return path;
}

// GET /api/documents?q=&category=&customer_id=
router.get('/', wrap(async (req, res) => {
  let q = supabase.from('documents').select(SELECT).order('updated_at', { ascending: false }).limit(500);
  if (req.query.category) q = q.eq('category', req.query.category);
  if (req.query.customer_id) q = q.eq('customer_id', req.query.customer_id);
  if (req.query.q) {
    const t = String(req.query.q).replace(/[%,()]/g, ' ').trim();
    if (t) q = q.or(`title.ilike.%${t}%,doc_number.ilike.%${t}%`);
  }
  res.json(check(await q));
}));

// POST /api/documents (multipart: file + title, category, doc_number, customer_id, part_id)
router.post('/', canWrite, upload.single('file'), wrap(async (req, res) => {
  const b = req.body;
  if (!req.file) throw new HttpError(400, 'File is required');
  if (!b.title || !CATEGORIES.includes(b.category)) throw new HttpError(400, 'Title and a valid category are required');
  const doc = check(await supabase.from('documents').insert({
    title: b.title, category: b.category, doc_number: b.doc_number || null,
    customer_id: b.customer_id || null, part_id: b.part_id || null, created_by: req.user.id,
  }).select('*').single());
  const path = await storeFile(doc.id, 1, req.file);
  check(await supabase.from('document_versions').insert({
    document_id: doc.id, version_no: 1, file_name: req.file.originalname, storage_path: path,
    mime_type: req.file.mimetype, size_bytes: req.file.size, change_note: b.change_note || 'Initial upload', uploaded_by: req.user.id,
  }));
  await audit(req, { action: 'CREATE', entity: 'document', entityId: doc.id, newValue: { title: doc.title, category: doc.category, version: 1 } });
  res.status(201).json(doc);
}));

// POST /api/documents/:id/versions (multipart: file + change_note) -> uploads a new version
router.post('/:id/versions', canWrite, upload.single('file'), wrap(async (req, res) => {
  if (!req.file) throw new HttpError(400, 'File is required');
  const { data: doc } = await supabase.from('documents').select('*').eq('id', req.params.id).single();
  if (!doc) throw new HttpError(404, 'Document not found');
  const next = doc.current_version + 1;
  const path = await storeFile(doc.id, next, req.file);
  check(await supabase.from('document_versions').insert({
    document_id: doc.id, version_no: next, file_name: req.file.originalname, storage_path: path,
    mime_type: req.file.mimetype, size_bytes: req.file.size, change_note: req.body.change_note || null, uploaded_by: req.user.id,
  }));
  check(await supabase.from('documents').update({ current_version: next }).eq('id', doc.id));
  await audit(req, { action: 'NEW_VERSION', entity: 'document', entityId: doc.id, oldValue: { version: doc.current_version }, newValue: { version: next } });
  res.status(201).json({ version: next });
}));

router.get('/:id/versions', wrap(async (req, res) => {
  res.json(check(await supabase.from('document_versions')
    .select('*, uploader:users!document_versions_uploaded_by_fkey(full_name)')
    .eq('document_id', req.params.id).order('version_no', { ascending: false })));
}));

// Signed download link for a version
router.get('/versions/:vid/url', wrap(async (req, res) => {
  const { data: v } = await supabase.from('document_versions').select('*').eq('id', req.params.vid).single();
  if (!v) throw new HttpError(404, 'Version not found');
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(v.storage_path, 120, { download: v.file_name });
  if (error) throw new HttpError(500, error.message);
  await audit(req, { action: 'DOWNLOAD', entity: 'document', entityId: v.document_id, newValue: { version: v.version_no } });
  res.json({ url: data.signedUrl });
}));

router.delete('/:id', requireRole('qa_manager'), wrap(async (req, res) => {
  const { data: doc } = await supabase.from('documents').select('*').eq('id', req.params.id).single();
  if (!doc) throw new HttpError(404, 'Document not found');
  const { data: vers } = await supabase.from('document_versions').select('storage_path').eq('document_id', doc.id);
  if (vers?.length) await supabase.storage.from(BUCKET).remove(vers.map((v) => v.storage_path));
  await supabase.from('documents').delete().eq('id', doc.id);
  await audit(req, { action: 'DELETE', entity: 'document', entityId: doc.id, oldValue: doc });
  res.json({ ok: true });
}));

module.exports = router;
