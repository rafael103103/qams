const router = require('express').Router();
const multer = require('multer');
const { supabase, BUCKET } = require('../config/supabase');
const { wrap, HttpError, check, pick } = require('../middleware/helpers');
const { audit, diff } = require('../services/audit');
const wf = require('../services/workflow');

const TYPES = ['PPAP Approval', 'Sample Submission', 'Packaging Approval', 'Limit Sample Approval', 'Engineering Change', '4M Change', 'Process Change Request', 'Deviation Request', 'Trial Request'];
const FIELDS = ['request_date', 'type', 'customer_id', 'part_id', 'part_number', 'part_name', 'description', 'reason', 'target_date'];
// Vercel functions accept ~4.5MB bodies, so keep uploads under that.
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024 } });
const LIST_SELECT = '*, customer:customers(id, name), requestor:users!requests_requestor_id_fkey(id, full_name)';

const isApprover = (u) => ['engineer', 'supervisor', 'qa_manager', 'admin'].includes(u.role);

/** Requestors only see their own requests; approvers/admin see all. */
function assertCanView(user, r) {
  if (user.role === 'requestor' && r.requestor_id !== user.id) throw new HttpError(403, 'You can only view your own requests');
}

// GET /api/requests?status=&customer_id=&type=&q=&mine=1&overdue=1
router.get('/', wrap(async (req, res) => {
  let q = supabase.from('requests').select(LIST_SELECT).order('created_at', { ascending: false }).limit(500);
  if (req.user.role === 'requestor' || req.query.mine) q = q.eq('requestor_id', req.user.id);
  for (const f of ['status', 'customer_id', 'type']) if (req.query[f]) q = q.eq(f, req.query[f]);
  if (req.query.q) {
    const t = String(req.query.q).replace(/[%,()]/g, ' ').trim();
    if (t) q = q.or(`request_no.ilike.%${t}%,part_number.ilike.%${t}%,part_name.ilike.%${t}%`);
  }
  if (req.query.overdue) q = q.lt('target_date', new Date().toISOString().slice(0, 10)).in('status', ['Pending', 'For Approval', 'Returned']);
  res.json(check(await q));
}));

// GET /api/requests/my-approvals : requests currently waiting for me
router.get('/my-approvals', wrap(async (req, res) => {
  if (!isApprover(req.user)) return res.json([]);
  const { data: steps } = await supabase.from('request_steps').select('request_id, approver_id, role').eq('status', 'Pending');
  const ids = (steps || []).filter((s) => req.user.role === 'admin' || (s.approver_id ? s.approver_id === req.user.id : s.role === req.user.role)).map((s) => s.request_id);
  if (!ids.length) return res.json([]);
  res.json(check(await supabase.from('requests').select(LIST_SELECT).in('id', ids).eq('status', 'For Approval').neq('requestor_id', req.user.id).order('target_date', { ascending: true })));
}));

// GET /api/requests/:id : full detail
router.get('/:id', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  assertCanView(req.user, r);
  const [steps, hist, files] = await Promise.all([
    supabase.from('request_steps').select('*, approver:users!request_steps_approver_id_fkey(full_name), actor:users!request_steps_acted_by_fkey(full_name)').eq('request_id', r.id).order('level'),
    supabase.from('approval_history').select('*').eq('request_id', r.id).order('created_at'),
    supabase.from('request_attachments').select('*').eq('request_id', r.id).order('created_at'),
  ]);
  const step = (steps.data || []).find((s) => s.level === r.current_level && s.status === 'Pending');
  r.can_act = r.status === 'For Approval' && !!step && wf.canAct(req.user, step) && r.requestor_id !== req.user.id;
  r.can_edit = ['Pending', 'Returned'].includes(r.status) && (r.requestor_id === req.user.id || req.user.role === 'admin');
  r.can_complete = r.status === 'Approved' && (r.requestor_id === req.user.id || req.user.role === 'admin');
  res.json({ request: r, steps: steps.data || [], history: hist.data || [], attachments: files.data || [] });
}));

// POST /api/requests : create (status Pending). Body may include approvers: {engineer, supervisor, qa_manager} user ids
router.post('/', wrap(async (req, res) => {
  const row = pick(req.body, FIELDS);
  if (!TYPES.includes(row.type)) throw new HttpError(400, 'Invalid request type');
  if (!row.customer_id || !(row.part_number || row.part_id)) throw new HttpError(400, 'Customer and part number are required');
  if (!row.description) throw new HttpError(400, 'Description is required');
  if (row.part_id) { // snapshot part info
    const { data: p } = await supabase.from('parts').select('part_number, part_name').eq('id', row.part_id).single();
    if (p) { row.part_number = p.part_number; row.part_name = row.part_name || p.part_name; }
  }
  row.requestor_id = req.user.id;
  const data = check(await supabase.from('requests').insert(row).select('*').single());
  await wf.createSteps(data.id, req.body.approvers || {});
  await audit(req, { action: 'CREATE', entity: 'request', entityId: data.request_no, newValue: row });
  res.status(201).json(data);
}));

// PUT /api/requests/:id : edit while Pending/Returned
router.put('/:id', wrap(async (req, res) => {
  const old = await wf.loadRequest(req.params.id);
  if (!['Pending', 'Returned'].includes(old.status)) throw new HttpError(409, 'Only Pending or Returned requests can be edited');
  if (old.requestor_id !== req.user.id && req.user.role !== 'admin') throw new HttpError(403, 'Only the requestor can edit this request');
  const upd = pick(req.body, FIELDS);
  if (upd.type && !TYPES.includes(upd.type)) throw new HttpError(400, 'Invalid request type');
  const data = check(await supabase.from('requests').update(upd).eq('id', old.id).select('*').single());
  if (req.body.approvers) {
    for (const [role, uid] of Object.entries(req.body.approvers))
      if (['engineer', 'supervisor', 'qa_manager'].includes(role))
        await supabase.from('request_steps').update({ approver_id: uid || null }).eq('request_id', old.id).eq('role', role);
  }
  const d = diff(old, upd);
  await audit(req, { action: 'UPDATE', entity: 'request', entityId: old.request_no, oldValue: d.old, newValue: d.new });
  res.json(data);
}));

router.post('/:id/submit', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  await wf.submit(r, req.user);
  await audit(req, { action: 'SUBMIT', entity: 'request', entityId: r.request_no, oldValue: { status: r.status }, newValue: { status: 'For Approval' } });
  res.json({ ok: true });
}));

// POST /api/requests/:id/action { action: approve|reject|return, comment }
router.post('/:id/action', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  const result = await wf.act(r, req.user, req.body.action, req.body.comment);
  const after = (await wf.loadRequest(r.id)).status;
  await audit(req, { action: req.body.action.toUpperCase(), entity: 'request', entityId: r.request_no, oldValue: { status: r.status, level: r.current_level }, newValue: { status: after, comment: req.body.comment || null } });
  res.json({ ok: true, ...result, status: after });
}));

router.post('/:id/complete', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  await wf.complete(r, req.user, req.body.comment);
  await audit(req, { action: 'COMPLETE', entity: 'request', entityId: r.request_no, oldValue: { status: 'Approved' }, newValue: { status: 'Completed' } });
  res.json({ ok: true });
}));

// Add a standalone comment to the history (any participant)
router.post('/:id/comment', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  assertCanView(req.user, r);
  if (!(req.body.comment || '').trim()) throw new HttpError(400, 'Comment is empty');
  check(await supabase.from('approval_history').insert({ request_id: r.id, level: r.current_level, action: 'Comment', user_id: req.user.id, user_name: req.user.full_name, user_role: wf.ROLE_LABEL[req.user.role], comment: req.body.comment.trim() }));
  res.json({ ok: true });
}));

// ---- Attachments ----
router.post('/:id/attachments', upload.array('files', 10), wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  if (r.requestor_id !== req.user.id && req.user.role !== 'admin' && !isApprover(req.user)) throw new HttpError(403, 'Not allowed');
  if (!req.files?.length) throw new HttpError(400, 'No files received');
  const saved = [];
  for (const f of req.files) {
    const safe = f.originalname.replace(/[^\w.\-]+/g, '_');
    const path = `requests/${r.id}/${Date.now()}_${safe}`;
    const up = await supabase.storage.from(BUCKET).upload(path, f.buffer, { contentType: f.mimetype });
    if (up.error) throw new HttpError(500, up.error.message);
    saved.push(check(await supabase.from('request_attachments').insert({ request_id: r.id, file_name: f.originalname, storage_path: path, mime_type: f.mimetype, size_bytes: f.size, uploaded_by: req.user.id }).select('*').single()));
  }
  await audit(req, { action: 'UPLOAD', entity: 'request', entityId: r.request_no, newValue: { files: saved.map((s) => s.file_name) } });
  res.status(201).json(saved);
}));

// Short-lived signed download link
router.get('/:id/attachments/:aid/url', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  assertCanView(req.user, r);
  const { data: a } = await supabase.from('request_attachments').select('*').eq('id', req.params.aid).eq('request_id', r.id).single();
  if (!a) throw new HttpError(404, 'Attachment not found');
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(a.storage_path, 120, { download: a.file_name });
  if (error) throw new HttpError(500, error.message);
  res.json({ url: data.signedUrl });
}));

router.delete('/:id/attachments/:aid', wrap(async (req, res) => {
  const r = await wf.loadRequest(req.params.id);
  if (!['Pending', 'Returned'].includes(r.status)) throw new HttpError(409, 'Attachments are locked once submitted');
  if (r.requestor_id !== req.user.id && req.user.role !== 'admin') throw new HttpError(403, 'Not allowed');
  const { data: a } = await supabase.from('request_attachments').select('*').eq('id', req.params.aid).eq('request_id', r.id).single();
  if (!a) throw new HttpError(404, 'Attachment not found');
  await supabase.storage.from(BUCKET).remove([a.storage_path]);
  await supabase.from('request_attachments').delete().eq('id', a.id);
  await audit(req, { action: 'DELETE', entity: 'request_attachment', entityId: r.request_no, oldValue: { file: a.file_name } });
  res.json({ ok: true });
}));

module.exports = router;
