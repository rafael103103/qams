const router = require('express').Router();
const { supabase } = require('../config/supabase');
const { requireRole } = require('../middleware/auth');
const { wrap, check } = require('../middleware/helpers');

// GET /api/audit?entity=&user=&action=&from=&to=&limit=
router.get('/', requireRole('qa_manager'), wrap(async (req, res) => {
  let q = supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(Math.min(Number(req.query.limit) || 200, 1000));
  if (req.query.entity) q = q.eq('entity', req.query.entity);
  if (req.query.action) q = q.eq('action', req.query.action);
  if (req.query.user) q = q.ilike('user_name', `%${String(req.query.user).replace(/[%,()]/g, '')}%`);
  if (req.query.from) q = q.gte('created_at', req.query.from);
  if (req.query.to) q = q.lte('created_at', req.query.to + 'T23:59:59Z');
  res.json(check(await q));
}));

module.exports = router;
