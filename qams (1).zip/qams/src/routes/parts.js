module.exports = require('./crud')({
  table: 'parts', entity: 'part', orderBy: 'part_number', asc: true,
  select: '*, customer:customers(id, name)',
  fields: ['part_number', 'part_name', 'customer_id', 'drawing_number', 'revision_number', 'process'],
  required: ['part_number', 'part_name'],
  searchCols: ['part_number', 'part_name', 'drawing_number'],
  filters: ['customer_id'],
  writeRoles: ['engineer', 'supervisor', 'qa_manager'],
});
