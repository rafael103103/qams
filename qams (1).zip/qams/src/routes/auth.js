const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { supabase } = require('../config/supabase');
const { signToken, authenticate } = require('../middleware/auth');
const { wrap, HttpError } = require('../middleware/helpers');
const { audit } = require('../services/audit');

const PUBLIC = 'id, full_name, email, role, department';

// POST /api/auth/login  { email, password }
router.post('/login', wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!email || !password) throw new HttpError(400, 'Email and password are required');

  const { data: user } = await supabase.from('users').select(`${PUBLIC}, password_hash, is_active`).eq('email', email).maybeSingle();
  // Same message for unknown user / wrong password (no user enumeration)
  const ok = user && user.is_active && await bcrypt.compare(password, user.password_hash);
  if (!ok) throw new HttpError(401, 'Invalid email or password');

  delete user.password_hash;
  req.user = user;
  await audit(req, { action: 'LOGIN', entity: 'user', entityId: user.id });
  res.json({ token: signToken(user), user });
}));

router.get('/me', authenticate, (req, res) => res.json({ user: req.user }));

// POST /api/auth/change-password { current, next }
router.post('/change-password', authenticate, wrap(async (req, res) => {
  const { current, next } = req.body;
  if (!next || next.length < 8) throw new HttpError(400, 'New password must be at least 8 characters');
  const { data } = await supabase.from('users').select('password_hash').eq('id', req.user.id).single();
  if (!(await bcrypt.compare(current || '', data.password_hash))) throw new HttpError(400, 'Current password is incorrect');
  await supabase.from('users').update({ password_hash: await bcrypt.hash(next, 12) }).eq('id', req.user.id);
  await audit(req, { action: 'PASSWORD_CHANGE', entity: 'user', entityId: req.user.id });
  res.json({ ok: true });
}));

module.exports = router;
