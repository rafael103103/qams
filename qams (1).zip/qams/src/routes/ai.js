// AI assistant endpoints (Google Gemini).
const router = require('express').Router();
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const ExcelJS = require('exceljs');
const { wrap, HttpError } = require('../middleware/helpers');
const { generate, tools } = require('../services/gemini');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024 } });
// Gemini free tier is rate limited, so protect it per user.
router.use(rateLimit({ windowMs: 60 * 1000, max: 10, keyGenerator: (req) => req.user.id, message: { error: 'Slow down: max 10 AI requests per minute.' }, validate: false }));

const MAX_CHARS = 20000;
const need = (v, name) => { if (!v || !String(v).trim()) throw new HttpError(400, `${name} is required`); return String(v).slice(0, MAX_CHARS); };

// Text tools: email | grammar | rephrase | capa | minutes
router.post('/:tool(email|grammar|rephrase|capa|minutes)', wrap(async (req, res) => {
  const b = req.body, tool = req.params.tool;
  const input = {
    email:    () => ({ ...b, details: need(b.details, 'Details') }),
    grammar:  () => ({ text: need(b.text, 'Text') }),
    rephrase: () => ({ ...b, text: need(b.text, 'Text') }),
    capa:     () => ({ ...b, problem: need(b.problem, 'Problem description') }),
    minutes:  () => ({ ...b, notes: need(b.notes, 'Meeting notes') }),
  }[tool]();
  const result = await generate([{ text: tools[tool](input) }], { temperature: tool === 'grammar' ? 0.2 : 0.5 });
  res.json({ result });
}));

// Inspection summarizer: paste text OR upload pdf / image / csv / txt / xlsx
router.post('/inspection', upload.single('file'), wrap(async (req, res) => {
  let text = (req.body.text || '').slice(0, MAX_CHARS);
  const parts = [];
  const f = req.file;
  if (f) {
    const name = f.originalname.toLowerCase();
    if (f.mimetype === 'application/pdf' || f.mimetype.startsWith('image/')) {
      parts.push({ inlineData: { mimeType: f.mimetype, data: f.buffer.toString('base64') } });
    } else if (name.endsWith('.xlsx')) {
      const wb = new ExcelJS.Workbook();
      await wb.xlsx.load(f.buffer);
      wb.eachSheet((ws) => {
        text += `\n--- Sheet: ${ws.name} ---\n`;
        ws.eachRow((row) => { text += row.values.slice(1).map((v) => (v && v.result !== undefined ? v.result : v ?? '')).join(' | ') + '\n'; });
      });
    } else if (/\.(csv|txt|tsv)$/.test(name) || f.mimetype.startsWith('text/')) {
      text += '\n' + f.buffer.toString('utf8');
    } else throw new HttpError(400, 'Unsupported file type. Use PDF, image, XLSX, CSV or TXT.');
  }
  if (!text.trim() && !parts.length) throw new HttpError(400, 'Paste inspection results or upload a file');
  parts.unshift({ text: tools.inspection({ text: text.slice(0, MAX_CHARS), instructions: req.body.instructions }) });
  res.json({ result: await generate(parts, { temperature: 0.2 }) });
}));

module.exports = router;
