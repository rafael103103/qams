// Generic CRUD router factory for simple master-data tables (customers, parts).
const express = require('express');
const { supabase } = require('../config/supabase');
const { requireRole } = require('../middleware/auth');
const { wrap, HttpError, check, pick } = require('../middleware/helpers');
const { audit, diff } = require('../services/audit');

/**
 * @param {object} o
 *  table, entity, fields (writable columns), required (fields), select (select string),
 *  searchCols (columns for ?q= search), writeRoles (roles allowed to modify; admin always allowed)
 */
module.exports = function crud(o) {
  const router = express.Router();
  const write = requireRole(...o.writeRoles);

  router.get('/', wrap(async (req, res) => {
    let q = supabase.from(o.table).select(o.select || '*').order(o.orderBy || 'created_at', { ascending: o.asc ?? false });
    if (req.query.q) {
      const term = String(req.query.q).replace(/[%,()]/g, ' ').trim();
      if (term) q = q.or(o.searchCols.map((c) => `${c}.ilike.%${term}%`).join(','));
    }
    if (o.filters) for (const f of o.filters) if (req.query[f]) q = q.eq(f, req.query[f]);
    res.json(check(await q));
  }));

  router.post('/', write, wrap(async (req, res) => {
    const row = pick(req.body, o.fields);
    for (const f of o.required) if (!row[f]) throw new HttpError(400, `${f.replace(/_/g, ' ')} is required`);
    const { data, error } = await supabase.from(o.table).insert(row).select(o.select || '*').single();
    if (error) throw new HttpError(error.code === '23505' ? 409 : 500, error.code === '23505' ? `${o.entity} already exists` : error.message);
    await audit(req, { action: 'CREATE', entity: o.entity, entityId: data.id, newValue: row });
    res.status(201).json(data);
  }));

  router.put('/:id', write, wrap(async (req, res) => {
    const { data: old } = await supabase.from(o.table).select('*').eq('id', req.params.id).single();
    if (!old) throw new HttpError(404, `${o.entity} not found`);
    const upd = pick(req.body, o.fields);
    const { data, error } = await supabase.from(o.table).update(upd).eq('id', req.params.id).select(o.select || '*').single();
    if (error) throw new HttpError(error.code === '23505' ? 409 : 500, error.code === '23505' ? `${o.entity} already exists` : error.message);
    const d = diff(old, upd);
    await audit(req, { action: 'UPDATE', entity: o.entity, entityId: req.params.id, oldValue: d.old, newValue: d.new });
    res.json(data);
  }));

  router.delete('/:id', requireRole('admin', 'qa_manager'), wrap(async (req, res) => {
    const { data: old } = await supabase.from(o.table).select('*').eq('id', req.params.id).single();
    if (!old) throw new HttpError(404, `${o.entity} not found`);
    const { error } = await supabase.from(o.table).delete().eq('id', req.params.id);
    if (error) throw new HttpError(500, error.message);
    await audit(req, { action: 'DELETE', entity: o.entity, entityId: req.params.id, oldValue: old });
    res.json({ ok: true });
  }));

  return router;
};
