// Daily due-date reminders. Triggered by Vercel Cron (see vercel.json) or any scheduler.
// Vercel automatically sends "Authorization: Bearer <CRON_SECRET>" when CRON_SECRET is set.
const router = require('express').Router();
const { supabase } = require('../config/supabase');
const { wrap, HttpError } = require('../middleware/helpers');
const { notifyUsers, template, linkTo } = require('../services/mailer');
const { stepApprovers } = require('../services/workflow');

const DAYS_AHEAD = 2; // remind when due within N days (or already overdue)

router.get('/reminders', wrap(async (req, res) => {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.authorization !== `Bearer ${secret}`) throw new HttpError(401, 'Unauthorized');

  const today = new Date().toISOString().slice(0, 10);
  const limit = new Date(Date.now() + DAYS_AHEAD * 86400000).toISOString().slice(0, 10);

  const { data: reqs } = await supabase.from('requests')
    .select('*, customer:customers(name), requestor:users!requests_requestor_id_fkey(id, full_name, email)')
    .in('status', ['Pending', 'For Approval', 'Returned'])
    .not('target_date', 'is', null).lte('target_date', limit)
    .or(`last_reminder_on.is.null,last_reminder_on.lt.${today}`);

  let sent = 0;
  for (const r of reqs || []) {
    const overdue = r.target_date < today;
    const recipients = [r.requestor];
    if (r.status === 'For Approval') {
      const { data: step } = await supabase.from('request_steps').select('*').eq('request_id', r.id).eq('level', r.current_level).single();
      if (step) recipients.push(...(await stepApprovers(step)));
    }
    const uniq = [...new Map(recipients.map((u) => [u.id, u])).values()];
    await notifyUsers(uniq, {
      event: 'due_reminder', request: r,
      title: `${overdue ? 'OVERDUE' : 'Due soon'}: ${r.request_no}`,
      message: `${r.type} for ${r.part_number || ''} - target date ${r.target_date}.`,
      html: template({
        heading: overdue ? 'Request is overdue' : 'Request due soon',
        intro: `This request ${overdue ? 'passed its target date' : 'is approaching its target date'} and is still "${r.status}".`,
        rows: [['Request No.', r.request_no], ['Type', r.type], ['Customer', r.customer?.name || '-'], ['Target date', r.target_date], ['Status', r.status]],
        buttonText: 'Open request', link: linkTo(r.id),
      }),
    });
    await supabase.from('requests').update({ last_reminder_on: today }).eq('id', r.id);
    sent++;
  }
  res.json({ ok: true, reminded: sent });
}));

module.exports = router;
