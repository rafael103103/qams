// Dashboard metrics. Computed in JS from slim rows (fine for tens of thousands of requests).
const router = require('express').Router();
const { supabase } = require('../config/supabase');
const { wrap, check } = require('../middleware/helpers');

const OPEN = ['Pending', 'For Approval', 'Returned'];
const monthKey = (d) => d.toISOString().slice(0, 7);

router.get('/', wrap(async (req, res) => {
  let q = supabase.from('requests').select('id, status, target_date, submitted_at, closed_at, created_at, customer:customers(name)');
  if (req.user.role === 'requestor') q = q.eq('requestor_id', req.user.id);
  const rows = check(await q);

  const today = new Date().toISOString().slice(0, 10);
  const counts = { pending: 0, approved: 0, rejected: 0, overdue: 0, forApproval: 0, total: rows.length };
  for (const r of rows) {
    if (r.status === 'Pending' || r.status === 'Returned') counts.pending++;
    if (r.status === 'For Approval') counts.forApproval++;
    if (r.status === 'Approved' || r.status === 'Completed') counts.approved++;
    if (r.status === 'Rejected') counts.rejected++;
    if (OPEN.includes(r.status) && r.target_date && r.target_date < today) counts.overdue++;
  }

  // Monthly submission trend: last 12 months
  const months = [];
  const now = new Date();
  for (let i = 11; i >= 0; i--) months.push(monthKey(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1))));
  const trend = Object.fromEntries(months.map((m) => [m, 0]));
  for (const r of rows) { const k = (r.submitted_at || r.created_at).slice(0, 7); if (k in trend) trend[k]++; }

  // Approval lead time (days) = submitted -> final approval, by month closed
  const lead = Object.fromEntries(months.map((m) => [m, []]));
  let all = [];
  for (const r of rows) {
    if (r.submitted_at && r.closed_at && ['Approved', 'Completed'].includes(r.status)) {
      const days = (new Date(r.closed_at) - new Date(r.submitted_at)) / 86400000;
      all.push(days);
      const k = r.closed_at.slice(0, 7); if (k in lead) lead[k].push(days);
    }
  }
  const avg = (a) => (a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(1) : 0);

  // Customer statistics
  const byCustomer = {};
  for (const r of rows) { const n = r.customer?.name || 'Unassigned'; byCustomer[n] = (byCustomer[n] || 0) + 1; }
  const customers = Object.entries(byCustomer).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count).slice(0, 10);

  res.json({
    counts,
    trend: { labels: months, data: months.map((m) => trend[m]) },
    leadTime: { labels: months, data: months.map((m) => avg(lead[m])), overall: avg(all) },
    customers,
  });
}));

module.exports = router;
