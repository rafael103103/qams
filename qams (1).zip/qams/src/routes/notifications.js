// In-app notification bell.
const router = require('express').Router();
const { supabase } = require('../config/supabase');
const { wrap, check } = require('../middleware/helpers');

router.get('/', wrap(async (req, res) => {
  const items = check(await supabase.from('notifications').select('*').eq('user_id', req.user.id).order('created_at', { ascending: false }).limit(30));
  res.json({ items, unread: items.filter((n) => !n.is_read).length });
}));

router.post('/read-all', wrap(async (req, res) => {
  await supabase.from('notifications').update({ is_read: true }).eq('user_id', req.user.id).eq('is_read', false);
  res.json({ ok: true });
}));

router.post('/:id/read', wrap(async (req, res) => {
  await supabase.from('notifications').update({ is_read: true }).eq('id', req.params.id).eq('user_id', req.user.id);
  res.json({ ok: true });
}));

module.exports = router;
