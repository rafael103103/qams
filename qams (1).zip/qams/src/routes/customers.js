module.exports = require('./crud')({
  table: 'customers', entity: 'customer', orderBy: 'name', asc: true,
  fields: ['name', 'contact_person', 'email', 'remarks'],
  required: ['name'],
  searchCols: ['name', 'contact_person', 'email'],
  writeRoles: ['engineer', 'qa_manager'],
});
