// Supabase client using the SERVICE ROLE key. Server-side only: never send this key to the browser.
const { createClient } = require('@supabase/supabase-js');

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) console.warn('[config] SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not set');

const supabase = createClient(url || 'http://localhost', key || 'missing', {
  auth: { persistSession: false, autoRefreshToken: false },
});

module.exports = { supabase, BUCKET: process.env.STORAGE_BUCKET || 'qams-files' };
