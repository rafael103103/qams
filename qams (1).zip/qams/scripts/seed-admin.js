// Creates the first administrator:  npm run seed:admin -- you@company.com "Your Name" "StrongPassword"
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { supabase } = require('../src/config/supabase');

(async () => {
  const [email, name, password] = process.argv.slice(2);
  if (!email || !name || !password) {
    console.error('Usage: npm run seed:admin -- <email> "<Full Name>" "<password>"');
    process.exit(1);
  }
  if (password.length < 8) { console.error('Password must be at least 8 characters'); process.exit(1); }
  const password_hash = await bcrypt.hash(password, 12);
  const { error } = await supabase.from('users').upsert(
    { email: email.toLowerCase(), full_name: name, password_hash, role: 'admin', is_active: true },
    { onConflict: 'email' });
  if (error) { console.error('Failed:', error.message); process.exit(1); }
  console.log(`Administrator ready: ${email}`);
})();
